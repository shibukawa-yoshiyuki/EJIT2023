#include <stdio.h>
#include <stdlib.h>

#define		 YES									1
#define		 NO										0
#define		 ANS									100
#define		 I_NUM_ARRAY_MAX						9
#define		 I_SYMBOL_ARRAY_MAX						9

int main(void) {
	
	// ���l1�`9�̔z��
	int iNumArray[I_NUM_ARRAY_MAX];

	// "�L��(+ - ��)�𐔒l�ŊǗ�"  "3 : +    2 : -    1 : ��"  "1�`3��3�i��" 
	int iSymbol = 333333333;  // �S�ԗ������F211111111�ɂȂ�܂Ńf�N�������g

	int iAnsCount = 0;
	while (1) {
		// iNumArray��������(���ɖ߂�)
		for (int i = 0; i < I_NUM_ARRAY_MAX; i++) {
			iNumArray[i] = (i + 1);
		}
		
		// "iSymbol�̐��l��1�������o��"  "�z��Ɋi�["
		int iSymbolArray[I_SYMBOL_ARRAY_MAX];
		iSymbolArray[0] = iSymbol / 100000000;
		iSymbolArray[1] = iSymbol / 10000000 - ((iSymbol / 100000000) * 10);
		iSymbolArray[2] = iSymbol / 1000000 - ((iSymbol / 10000000) * 10);
		iSymbolArray[3] = iSymbol / 100000 - ((iSymbol / 1000000) * 10);
		iSymbolArray[4] = iSymbol / 10000 - ((iSymbol / 100000) * 10);
		iSymbolArray[5] = iSymbol / 1000 - ((iSymbol / 10000) * 10);
		iSymbolArray[6] = iSymbol / 100 - ((iSymbol / 1000) * 10);
		iSymbolArray[7] = iSymbol / 10 - ((iSymbol / 100) * 10);
		iSymbolArray[8] = iSymbol / 1 - ((iSymbol / 10) * 10);

		// 3�i������
		int iContenueFlag = NO;
		for (int i = 0; i < I_SYMBOL_ARRAY_MAX; i++) {
			if (!(1 <= iSymbolArray[i] && iSymbolArray[i] <= 3)) {
				iContenueFlag = YES;
			}
		}
		if (iContenueFlag == YES) {
			iSymbol--;
			continue;
		}

		// ���̌��o
		int iTempNum = 0, i1Count = 0;
		for (int i = 0; i < I_SYMBOL_ARRAY_MAX; i++) {
			if (iSymbolArray[i] == 1 && 0 < i) {
				iNumArray[i - 1 - i1Count] *= 10;
				iNumArray[i - 1 - i1Count] += iNumArray[i];
				iNumArray[i] = 0;
				i1Count++;
			}
			else {
				iTempNum = 0;
				i1Count = 0;
			}
		}

		// -�̌��o
		for (int i = 0; i < I_SYMBOL_ARRAY_MAX; i++) {
			if (iSymbolArray[i] == 1) {
				continue;
			}
			if (iSymbolArray[i] == 2) {
				iNumArray[i] *= -1;
			}
		}

		// �v�Z
		int iAddNum = 0;
		for (int i = 0; i < I_NUM_ARRAY_MAX; i++) {
			iAddNum += iNumArray[i];
		}

		// ����
		if (iAddNum == ANS) {
			iAnsCount++;
			// �v�Z�����o��
			char cShow[128];
			memset(cShow, '\0', sizeof(cShow));
			for (int i = 0; i < I_NUM_ARRAY_MAX; i++) {
				if (iNumArray[i] == 0) {
					continue;
				}
				if (i == 0) {
					if (0 <= iNumArray[i]) {
						sprintf(cShow, "%s  %d ", cShow, iNumArray[i]);
					}
					else {
						sprintf(cShow, "%s- %d ", cShow, (iNumArray[i] * -1));
					}
					continue;
				}
				if (0 <= iNumArray[i]) {
					sprintf(cShow, "%s+ %d ", cShow, iNumArray[i]);
				}
				else {
					sprintf(cShow, "%s- %d ", cShow, (iNumArray[i] * -1));
				}
			}
			sprintf(cShow, "%s= %d ", cShow, iAddNum);
			printf("%02d: %s\n", iAnsCount, cShow);
		}

		// iSymbol���f�N�������g
		iSymbol--;

		// �I����������
		if (iSymbol < 211111111) {
			break;
		}
	}
	
	printf("\n");

	return 0;
}