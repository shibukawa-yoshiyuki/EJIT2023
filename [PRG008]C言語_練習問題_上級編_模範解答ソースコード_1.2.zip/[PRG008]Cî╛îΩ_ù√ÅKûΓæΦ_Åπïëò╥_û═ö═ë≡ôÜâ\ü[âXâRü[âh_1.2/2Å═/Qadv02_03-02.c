﻿#include <stdio.h>
#include <stdlib.h>

#define		 YES						1
#define		 NO							0

// 構造体
typedef struct _dataStruct{
	int iNum;
	struct dataStruct* next;
}dataStruct;

dataStruct* pushStack(dataStruct* ds, int iNum)
{
	dataStruct* dsTemp = (dataStruct*)malloc(sizeof(dataStruct));
	if (dsTemp == NULL) {
		printf("\n\nエラー\n");
		return -1;
	}
	dsTemp->iNum = iNum;
	dsTemp->next = ds;
	ds = dsTemp;

	return ds;
}
dataStruct* popStack(dataStruct* ds)
{
	printf("POPで取り出した値:      %d\n", ds->iNum);
	dataStruct* dsTemp = ds->next;
	free(ds);
	dataStruct* reds = dsTemp;

	printf("---現在のスタックの状態---\n");
	int i = 0;
	for (i = 0; dsTemp->next != NULL; i++) {
		printf("#  %d\n", dsTemp->iNum);
		dsTemp = dsTemp->next;
	}
	if (i == 0) {
		printf("空っぽです。\n");
	}
	printf("------\n");

	return reds;
}
void print(dataStruct* ds)
{
	printf("---現在のスタックの状態---\n");
	while (ds->next != NULL) {
		printf("#  %d\n", ds->iNum);
		ds = ds->next;
	}
	printf("------\n");
}

int main(void) {

	// 構造体の実体
	dataStruct* ds;
	ds = (dataStruct*)malloc(sizeof(dataStruct));
	if (ds == NULL) {
		printf("\n\nエラー\n");
		return -1;
	}
	ds->next = NULL;

	int iNum;

	while (1) {

		printf("99までの整数値を入力してください。(0を入力すると終了します。)\n>");

		// 標準入力
		int iError = scanf("%d", &iNum);
		// scanfがエラーを返した場合、-1でプログラムを終了
		if (iError == EOF || iError == (EOF + 1)) {
			printf("scanfでエラー\nプログラムを終了します。\n");
			return -1;
		}

		if (iNum == 0) {
			break;
		}
		
		ds = pushStack(ds, iNum);

		print(ds);
	}

	printf("入力された値をスタックから取り出して表示します。\n");

	while (ds->next != NULL) {
		ds = popStack(ds);
	}

	printf("\n\n終了\n\n");

	return 0;
}