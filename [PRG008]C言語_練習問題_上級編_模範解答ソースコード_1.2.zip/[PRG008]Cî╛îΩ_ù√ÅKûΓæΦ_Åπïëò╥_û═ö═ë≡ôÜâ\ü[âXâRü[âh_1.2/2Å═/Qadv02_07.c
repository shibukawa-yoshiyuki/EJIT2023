#include <stdio.h>
#include <stdlib.h>


// �萔
#define		INPUT_NUM_ARRAY_MAX					4
#define		INPUT_NUM_ARRAY_PATTERN_MAX			4
#define		SYMBOL_PATTERN_MAX					444
#define		SYMBOL_ARRAY_MAX					3
#define		ALL_NUM_ARRAY_MAX					24
#define		TEMP_ARRAY_MAX						2000	// ���߂Ɋm��
#define		SHOWSTR_ARRAY_MAX					1024	// ���߂Ɋm��
#define		SHOWSTR_ARRAY_CHAR_MAX				128		// ���߂Ɋm��
#define		ANS									10		

// �v���g�^�C�v
void searchPattern(short allNumArray[ALL_NUM_ARRAY_MAX][INPUT_NUM_ARRAY_MAX], short** tempNumArray);
void inputNum4PatternSearch(int inputNumArray[INPUT_NUM_ARRAY_MAX], short** tempNumArray);
void calculation(short** tempNumArray, int iSymbol, short allNumArray[ALL_NUM_ARRAY_MAX][INPUT_NUM_ARRAY_MAX], char** showStr);
void showCorrectAnswer(char** showStr);

/**** �e���p�Y�� ****/
int main() {

	// �����_�� or ���͒l
//	int inputNumArray[] = { 1,2,3,4 };
	int inputNumArray[] = { 1,2,3,4 };
	char inputbuf[5];
	printf("4�̐�������͂��Ă��������B(���͗�:1234)\n>");
	scanf("%s",inputbuf);
	for (int i = 0; i < 4;i++) {
		inputNumArray[i]=inputbuf[i]-'0';
	}

	// "�����ȃp�^�[���̐����z����i�[" "�󋵂ɂ���ă��Z�b�g���Ďg���܂킷" "�T�C�Y���傫���̂Ńq�[�v�Ɋm��"
	short** tempNumArray = NULL;
	tempNumArray = (short**)malloc(sizeof(short*) * TEMP_ARRAY_MAX);
	if (tempNumArray == NULL)  return -1;
	for (short i = 0; i < TEMP_ARRAY_MAX; i++) {
		if (tempNumArray[i] == NULL)  return -1;
		tempNumArray[i] = (short*)malloc(sizeof(short) * INPUT_NUM_ARRAY_MAX);
	}

	// tempNumArray�̎Q�Ɛ�� 0(�[��)�ŏ�����
	for (short i = 0; i < TEMP_ARRAY_MAX; i++) {
		for (short j = 0; j < INPUT_NUM_ARRAY_MAX; j++) {
			if (tempNumArray[i] == NULL)  return -1;
			*tempNumArray[i] = 0;
		}
	}

	// "�e���l��擪�ɂ����z������o" "tempNumArray�ɕێ�"
	inputNum4PatternSearch(inputNumArray, tempNumArray);
	//---
	// �S�p�^�[���̐����z����i�[
	short allNumArray[ALL_NUM_ARRAY_MAX][INPUT_NUM_ARRAY_MAX];

	// allNumArray�̎Q�Ɛ�� 0(�[��)�ŏ�����
	memset(allNumArray, 0, sizeof(allNumArray));

	// "�R�̋L���𐔒l�ŕ\������" "4:+  3:-  2:*  1:/"
	const int iSymbol = SYMBOL_PATTERN_MAX;

	// �SPattern���o
	searchPattern(allNumArray, tempNumArray);

	// tempNumArray�̎Q�Ɛ�� 0(�[��)�ŏ�����
	for (short i = 0; i < TEMP_ARRAY_MAX; i++) {
		for (short j = 0; j < INPUT_NUM_ARRAY_MAX; j++) {
			if (tempNumArray[i] == NULL)  return -1;
			tempNumArray[i][j] = 0;
		}
	}

	// "�v�Z���ʂ�10�ɂȂ����v�Z�����i�[����" "�T�C�Y���傫���̂Ńq�[�v�Ɋm��"
	char** showStr = NULL;
	showStr = (char**)malloc(sizeof(char*) * SHOWSTR_ARRAY_MAX);
	if (showStr == NULL)  return -1;
	for (short i = 0; i < SHOWSTR_ARRAY_MAX; i++) {
		if (showStr[i] == NULL)  return -1;
		showStr[i] = (char*)malloc(sizeof(char) * SHOWSTR_ARRAY_CHAR_MAX);
	}

	// showStr�̎Q�Ɛ�� \0�ŏ�����
	for (short i = 0; i < SHOWSTR_ARRAY_MAX; i++) {
		for (short j = 0; j < SHOWSTR_ARRAY_CHAR_MAX; j++) {
			if (showStr[i] == NULL)  return -1;
			memset(showStr[i], '\0', sizeof(showStr[i]));
		}
	}

	// �v�Z
	calculation(tempNumArray, iSymbol, allNumArray, showStr);

	// �\��
	showCorrectAnswer(showStr);

	// �q�[�v�Ɋm�ۂ����z����J��
	for (short i = 0; i < TEMP_ARRAY_MAX; i++) {
		free(tempNumArray[i]);
	}
	free(tempNumArray);
	for (short i = 0; i < SHOWSTR_ARRAY_MAX; i++) {
		free(showStr[i]);
	}
	free(showStr);

	printf("\n�I��\n");

	return 0;
}

// �\��
void showCorrectAnswer(char** showStr) {
	int i = 0, count = 0;
	for (; i < SHOWSTR_ARRAY_MAX; i++) {
		if (showStr[i][0] == '\0')  break;
		printf("���ԍ� :%02d\t%s\n", (i + 1), showStr[i]);
		count++;
	}
	if (0 < i)  printf("\n������ ���̃p�^�[���� �F %d\n", count);
	else        printf("\n������ �Y�����鎮�͂���܂���\n");
}

// �v�Z
void calculation(short** tempNumArray, int iSymbol, short allNumArray[ALL_NUM_ARRAY_MAX][INPUT_NUM_ARRAY_MAX], char** showStr) {
	int showStrIndex = 0;
	for (int num = 0; num < ALL_NUM_ARRAY_MAX; num++) {
		int iSymbolCopy = iSymbol;
		for (int temp = 0; ; temp++) {
			int symbolArray[SYMBOL_ARRAY_MAX];
			symbolArray[0] = iSymbolCopy / 100;
			symbolArray[1] = iSymbolCopy / 10 - symbolArray[0] * 10;
			symbolArray[2] = iSymbolCopy / 1 - symbolArray[0] * 100 - symbolArray[1] * 10;
			// 4�i���Ȃ̂�
			int isCon = 0;
			for (int j = 0; j < 3; j++) {
				if (!(1 <= symbolArray[j] && symbolArray[j] <= 4))  isCon = 1;
			}
			if (isCon == 1) {
				iSymbolCopy -= 1;
				temp--;
				continue;
			}

			tempNumArray[temp][0] = allNumArray[num][0];
			for (int j = 0; j < 3; j++) {
				tempNumArray[temp][j + 1] = allNumArray[num][j + 1];
			}

			for (int j = 0; j < 3; j++) {
				switch (symbolArray[j])
				{
				case 4:  // +
					break;
				case 3:  // -
					tempNumArray[temp][j + 1] = tempNumArray[temp][j + 1] * (-1);
					break;
				case 2:  // *
					tempNumArray[temp][j + 1] = tempNumArray[temp][j] * tempNumArray[temp][j + 1];
					tempNumArray[temp][j] = 0;
					break;
				case 1:  // /
					if (tempNumArray[temp][j + 1] != 0) {
						tempNumArray[temp][j + 1] = tempNumArray[temp][j] / tempNumArray[temp][j + 1];
						tempNumArray[temp][j] = 0;
					}
					else {
						// �[�����̏ꍇ�͑S��0�ɂ���(�v�Z���Ȃ�)
						for (int k = 0; k < 4; k++) {
							tempNumArray[temp][k] = 0;
						}
					}
					break;
				default:
					break;
				}
			}
			// ���v�l
			int sum = 0;
			for (int j = 0; j < 4; j++) {
				sum += tempNumArray[temp][j];
			}

			if (sum == ANS) {
				// �v�Z���o�͂̂��߃}�C�i�X����������
				for (int j = 0; j < 4; j++) {
					if (allNumArray[num][j] < 0)  allNumArray[num][j] *= -1;
				}
				char str[128];
				memset(str, '\0', sizeof(str));
				int strSize = sizeof(str);
				sprintf_s(str, strSize, " %d ", allNumArray[num][0]);
				for (int n = 1, k = 0; n < 4; n++) {
					switch (symbolArray[k])
					{
					case 4:  // +
						sprintf_s(str, strSize, "%s+ %d ", str, allNumArray[num][n]);
						break;
					case 3:  // -
						sprintf_s(str, strSize, "%s- %d ", str, allNumArray[num][n]);
						break;
					case 2:  // *
						sprintf_s(str, strSize, "%s* %d ", str, allNumArray[num][n]);
						break;
					case 1:  // /
						sprintf_s(str, strSize, "%s/ %d ", str, allNumArray[num][n]);
						break;
					default:
						break;
					}
					k++;
				}
				sprintf_s(str, strSize, "%s= %d ", str, sum);
				sprintf_s(showStr[showStrIndex], strSize, "%s", str);
				showStrIndex++;
			}

			iSymbolCopy -= 1;
			if (iSymbolCopy < 111)  break;
		}
	}

	return;
}

// �S�̐��l�A���ꂼ���擪�ɂ���4�p�^�[���̔z���tempNumArray�Ɋi�[����֐�
void inputNum4PatternSearch(int inputNumArray[INPUT_NUM_ARRAY_MAX], short** tempNumArray) {
	// �z��[0]�Ԗڂ�inputNumArray�̑S�p�^�[�����i�[����
	tempNumArray[0][0] = inputNumArray[0];
	tempNumArray[1][0] = inputNumArray[1];
	tempNumArray[2][0] = inputNumArray[2];
	tempNumArray[3][0] = inputNumArray[3];
	// "�z��[1]�Ԗڈȍ~��inputNumArray�̑S�p�^�[�����i�[����" "���������l������Ȃ��悤��"
	for (int pattern = 0; pattern < INPUT_NUM_ARRAY_PATTERN_MAX; pattern++) {
		if (0 == pattern) {  // 1
			//tempNumArray[0][pattern] = inputNumArray[pattern];    
			tempNumArray[1][pattern + 1] = inputNumArray[pattern];
			tempNumArray[2][pattern + 1] = inputNumArray[pattern];
			tempNumArray[3][pattern + 1] = inputNumArray[pattern];
		}
		if (1 == pattern) {  // 2
			tempNumArray[0][pattern] = inputNumArray[pattern];
			//tempNumArray[1][pattern + 1] = inputNumArray[pattern];
			tempNumArray[2][pattern + 1] = inputNumArray[pattern];
			tempNumArray[3][pattern + 1] = inputNumArray[pattern];
		}
		if (2 == pattern) {  // 3
			tempNumArray[0][pattern] = inputNumArray[pattern];
			tempNumArray[1][pattern] = inputNumArray[pattern];
			//tempNumArray[2][pattern] = inputNumArray[pattern - 1];
			tempNumArray[3][pattern + 1] = inputNumArray[pattern];
		}
		if (3 == pattern) {  // 4
			tempNumArray[0][pattern] = inputNumArray[pattern];
			tempNumArray[1][pattern] = inputNumArray[pattern];
			tempNumArray[2][pattern] = inputNumArray[pattern];
			//tempNumArray[3][pattern] = inputNumArray[pattern - 1];
		}
	}
	return;
}

void searchPattern(short allNumArray[ALL_NUM_ARRAY_MAX][INPUT_NUM_ARRAY_MAX], short** tempNumArray) {
	int temp;
	for (int index = 0; index < ALL_NUM_ARRAY_MAX; ) {
		for (int i = 0; i < 4 || index < ALL_NUM_ARRAY_MAX; i++) {  // 6�p�^�[��
			// �
			for (int pattern = 0; pattern < 4; pattern++) {    // 1 2 3 4
				allNumArray[index][pattern] = tempNumArray[i][pattern];
			}
			index++;
			// ��납��2��
			for (int j = 0; j < 2; j++) {    // 1 2 4 3    1 4 2 3
				temp = allNumArray[index - 1][INPUT_NUM_ARRAY_PATTERN_MAX - (j + 1)];
				tempNumArray[i][INPUT_NUM_ARRAY_MAX - (j + 1)] = allNumArray[index - 1][INPUT_NUM_ARRAY_PATTERN_MAX - (j + 2)];
				tempNumArray[i][INPUT_NUM_ARRAY_MAX - (j + 2)] = temp;
				for (int pattern = 0; pattern < INPUT_NUM_ARRAY_PATTERN_MAX; pattern++) {
					allNumArray[index][pattern] = tempNumArray[i][pattern];
				}
				index++;
			}
			// ��납��2��
			for (int j = 0; j < 2; j++) {  // 1 4 3 2    1 3 4 2
				temp = allNumArray[index - 1][INPUT_NUM_ARRAY_PATTERN_MAX - (j + 1)];
				tempNumArray[i][INPUT_NUM_ARRAY_MAX - (j + 1)] = allNumArray[index - 1][INPUT_NUM_ARRAY_PATTERN_MAX - (j + 2)];
				tempNumArray[i][INPUT_NUM_ARRAY_MAX - (j + 2)] = temp;
				for (int pattern = 0; pattern < INPUT_NUM_ARRAY_PATTERN_MAX; pattern++) {
					allNumArray[index][pattern] = tempNumArray[i][pattern];
				}
				index++;
			}
			// ��납��1��
			for (int j = 0; j < 1; j++) {  // 1 3 2 4
				temp = allNumArray[index - 1][INPUT_NUM_ARRAY_PATTERN_MAX - (j + 1)];
				tempNumArray[i][INPUT_NUM_ARRAY_MAX - (j + 1)] = allNumArray[index - 1][INPUT_NUM_ARRAY_PATTERN_MAX - (j + 2)];
				tempNumArray[i][INPUT_NUM_ARRAY_MAX - (j + 2)] = temp;
				for (int pattern = 0; pattern < INPUT_NUM_ARRAY_PATTERN_MAX; pattern++) {
					allNumArray[index][pattern] = tempNumArray[i][pattern];
				}
				index++;
			}
		}
	}

	return;
}