#include <stdio.h>
#include <stdlib.h>

#define		 YES						1
#define		 NO							0
#define		 CHAR_SIZE					256

typedef struct _charStack {
	char str[CHAR_SIZE];
	struct charStack* next;
	struct charStack* before;
	struct charStack* first;
	struct charStack* last;
} charStack;

// �X�^�b�N�ɓ����
void push(char stack[CHAR_SIZE], char c[CHAR_SIZE]);
void push_c(char stack[CHAR_SIZE], char c);
void rePolish(char str[CHAR_SIZE], char stack[CHAR_SIZE]);
charStack* createStack();
charStack* pushStack(charStack* cs, char str[CHAR_SIZE]);
charStack* popStackNum(charStack* cs, double* dNum);
charStack* calcStack(charStack* cs, char symbol);
double ctod(char c);
void freeStack(charStack* cs);
charStack* popStack(charStack* cs, char buf[CHAR_SIZE]);



int main(void) {

	printf("()���܂܂Ȃ��l�����Z�̌v�Z������͂��Ă��������B\n���l��2���܂ł̐����A���Z�q �����Z:+�A�����Z:-�A�|���Z:*�A����Z:/\n>");

	char str[CHAR_SIZE];
	memset(str, '\0', sizeof(str));
	// �W������
	//int iError = scanf("%s", &str);
	//// scanf���G���[��Ԃ����ꍇ�A-1�Ńv���O�������I��
	//if (iError == EOF || iError == (EOF + 1)) {
	//	printf("scanf�ŃG���[\n�v���O�������I�����܂��B\n");
	//	return -1;
	//}
	//sprintf(str, "%s", "11+100*2-1.5");
	sprintf(str, "%s", "12*3+45/6-7");

	char stack[CHAR_SIZE];
	memset(stack, '\0', sizeof(stack));

	// stack�ɋt�|�[�����h�̎�������(��؂�͔��p�u�����N)
	rePolish(str, stack);

	// stack�̎n�_
	charStack* cs = createStack();
	// �������o���p
	char cStock[CHAR_SIZE];
	memset(cStock, '\0', sizeof(cStock));

	for (int i = 0; ; i++) {
		if (('0' <= stack[i] && stack[i] <= '9') || stack[i] == '.') {
			sprintf(cStock, "%s%c", cStock, stack[i]);
			continue;
		}
		if (stack[i] == ' ' && cStock[0] != '\0') {
			cs = pushStack(cs, cStock);
			memset(cStock, '\0', sizeof(cStock));
			continue;
		}
		if (stack[i] == '\0') {
			break;
		}
		if (stack[i] != ' ') {
			cs = calcStack(cs, stack[i]);
		}
	}

	printf("%s=", str);
	int dottoFlag = NO, count = 0;
	for (int i = 0; ; i++) {
		if (cs->str[i] == '.') {
			dottoFlag = YES;
		}
		if (dottoFlag == YES) {
			count++;
		}
		printf("%c", cs->str[i]);
		if (count == 3) {
			break;
		}
	}
	printf("\n");


	charStack* temp = NULL;
	temp = cs;
	while (1) {
		if (temp == NULL) {
			break;
		}
		temp = cs->before;
		free(cs);
		cs = temp;
	}

	printf("\n\n�I��\n\n");

	return 0;
}

void rePolish(char str[CHAR_SIZE], char stack[CHAR_SIZE]) {
	charStack* cs;
	cs = createStack();

	char buf[CHAR_SIZE];
	memset(buf, '\0', sizeof(buf));

	// ���𕪉�
	for (int i = 0; ; i++) {
		if (('0' <= str[i] && str[i] <= '9') || str[i] == '.') {
			push_c(buf, str[i]);
		}
		else {
			cs = pushStack(cs, buf);
			memset(buf, '\0', sizeof(buf));
			push_c(buf, str[i]);
			cs = pushStack(cs, buf);
			memset(buf, '\0', sizeof(buf));
		}
		if (str[i] == '\0') {
			break;
		}
	}

	memset(buf, '\0', sizeof(buf));
	charStack* cs2;
	cs2 = createStack();
	// �擪����
	charStack* temp;
	cs = cs->first;
	cs = cs->next;
	temp = cs->first;

	// * / ����ւ�
	while (1) {
		cs = popStack(cs, buf);
		if (buf[0] == '*' || buf[0] == '/') {
			if (cs->next != NULL) {
				cs2 = pushStack(cs2, cs->str);
				cs = cs->next;
			}
		}
		cs2 = pushStack(cs2, buf);
		memset(buf, '\0', sizeof(buf));
		if (cs->next == NULL) {
			break;
		}
	}

	// ���
	freeStack(cs);

	memset(buf, '\0', sizeof(buf));
	charStack* cs3;
	charStack* temp2;
	cs3 = createStack();
	// �擪����
	cs2 = cs2->first;
	cs2 = cs2->next;
	temp = cs2;
	temp2 = cs2->first;

	// + - ����ւ�
	while (1) {
		char c[CHAR_SIZE];
		memset(c, '\0', sizeof(c));

		if (cs2 == NULL) {
			break;
		}
		cs2 = popStack(cs2, buf);
		if (buf[0] == '+' || buf[0] == '-') {
			while (1) {
				temp = cs2;
				if (temp != NULL) {
					cs2 = popStack(temp, c);
				}
				if (temp == NULL) {
					break;
				}
				if (c[0] == '+' || c[0] == '-') {
					cs2 = temp;
					break;
				}
				cs3 = pushStack(cs3, c);
				memset(c, '\0', sizeof(c));
			}
		}
		cs3 = pushStack(cs3, buf);
		memset(buf, '\0', sizeof(buf));
	}

	// ���
	cs2 = temp2;
	freeStack(cs2);
	memset(buf, '\0', sizeof(buf));
	cs3 = cs3->first;
	temp = cs3->next;

	temp = popStack(temp, buf);
	sprintf(stack, "%s ", buf);
	while (1) {
		if (temp == NULL) {
			break;
		}
		temp = popStack(temp, buf);
		sprintf(stack, "%s %s ", stack, buf);
		//printf("%s ", buf);
		memset(buf, '\0', sizeof(buf));
	}

	// ���
	cs3 = cs3->first;
	freeStack(cs3);
}

// �X�^�b�N�ɓ����
void push(char stack[CHAR_SIZE], char c[CHAR_SIZE])
{
	sprintf(stack, "%s%s", stack, c);
}
void push_c(char stack[CHAR_SIZE], char c)
{
	sprintf(stack, "%s%c", stack, c);
}

charStack* createStack()
{
	charStack* cs;
	cs = (charStack*)malloc(sizeof(charStack));
	if (cs == NULL) {
		printf("ERROR  createStack\n");
		exit(1);
	}
	cs->before = NULL;
	cs->next = NULL;
	cs->first = cs;
	cs->last = cs;
	memset(cs->str, '\0', sizeof(cs->str));
	return cs;
}

charStack* pushStack(charStack* cs, char str[CHAR_SIZE])
{
	charStack* temp;
	temp = (charStack*)malloc(sizeof(charStack));
	if (temp == NULL) {
		printf("ERROR  pushStack\n");
		exit(1);
	}
	cs->next = temp;
	temp->first = cs->first;
	temp->before = cs;
	temp->next = NULL;
	temp->last = temp;
	memset(temp->str, '\0', sizeof(temp->str));
	sprintf(temp->str, "%s", str);
	return temp;
}

charStack* popStackNum(charStack* cs, double* dNum)
{
	int dottoFlag = NO, count = 0;;
	for (int i = 0; ; i++) {
		if (cs->str[i] == '.') {
			dottoFlag = YES;
		}
		if (dottoFlag == YES) {
			if (count == 2) {
				*dNum /= 100;
				break;
			}
			*dNum += ctod(cs->str[i]);
			*dNum *= 10;
			count++;
			continue;
		}
		if (cs->str[i] == '\0') {
			break;
		}
		*dNum *= 10;
		*dNum += ctod(cs->str[i]);
	}
	charStack* temp;
	temp = cs->before;
	temp->next = NULL;
	free(cs);
	return temp;
}

charStack* calcStack(charStack* cs, char symbol)
{
	charStack* temp = NULL;
	double dNum1 = 0, dNum2 = 0;
	cs = popStackNum(cs, &dNum1);
	cs = popStackNum(cs, &dNum2);
	char str[CHAR_SIZE];
	memset(str, '\0', sizeof(str));
	switch (symbol) {
	case '+':
		sprintf(str, "%lf", (dNum2 + dNum1));
		temp = pushStack(cs, str);
		break;
	case '-':
		sprintf(str, "%lf", (dNum2 - dNum1));
		temp = pushStack(cs, str);
		break;
	case '*':
		sprintf(str, "%lf", (dNum2 * dNum1));
		temp = pushStack(cs, str);
		break;
	case '/':
		sprintf(str, "%lf", (dNum2 / dNum1));
		temp = pushStack(cs, str);
		break;
	default:
		break;
	}
	return temp;
}

double ctod(char c)
{
	double dNum = 0;
	if ('0' <= c && c <= '9') {
		dNum = c - '0';
	}
	return dNum;
}

void freeStack(charStack* cs)
{
	if (cs == NULL) {
		return;
	}
	charStack* temp;
	cs = cs->first;
	temp = cs->next;
	free(cs);
	while (1) {
		if (temp == NULL) {
			break;
		}
		cs = temp;
		temp = cs->next;
		if (temp != NULL) {
			free(cs);
		}
	}
}
charStack* popStack(charStack* cs, char buf[CHAR_SIZE])
{
	sprintf(buf, "%s", cs->str);
	charStack* temp;
	temp = cs->next;
	return; temp;
}