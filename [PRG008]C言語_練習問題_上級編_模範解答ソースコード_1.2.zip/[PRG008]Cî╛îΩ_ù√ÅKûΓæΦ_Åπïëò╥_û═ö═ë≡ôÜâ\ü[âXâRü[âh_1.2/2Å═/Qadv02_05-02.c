#include <stdio.h>
#include <stdlib.h>

#define		 YES						1
#define		 NO							0
#define		 CHAR_SIZE					256

typedef struct _charStack {
	char str[CHAR_SIZE];
	struct charStack* next;
	struct charStack* before;
	struct charStack* first;
	struct charStack* last;
} charStack;

charStack* createStack();
charStack* pushStack(charStack* cs, char buf[CHAR_SIZE]);
charStack* popStack(charStack* cs, char buf[CHAR_SIZE]);
void push_c(char buf[CHAR_SIZE], char c);
void freeStack(charStack* cs);

int main(void) {

	printf("()���܂܂Ȃ��l�����Z�̌v�Z������͂��Ă��������B\n(�����Z:+�A�����Z : -�A�|���Z : *�A����Z : / )\n>");

	char str[CHAR_SIZE];
	memset(str, '\0', sizeof(str));
	// �W������
	//int iError = scanf("%s", &str);
	//// scanf���G���[��Ԃ����ꍇ�A-1�Ńv���O�������I��
	//if (iError == EOF || iError == (EOF + 1)) {
	//	printf("scanf�ŃG���[\n�v���O�������I�����܂��B\n");
	//	return -1;
	//}
	//sprintf(str, "%s", "12*3+45/9");
	sprintf(str, "%s", "11+100*2-1");

	printf("���͂��ꂽ��:%s\n", str);
	printf("���͂��ꂽ�����t�|�[�����h�L�@�ɒu�������܂���\n");

	charStack* cs;
	cs = createStack();

	char buf[CHAR_SIZE];
	memset(buf, '\0', sizeof(buf));

	// ���𕪉�
	for (int i = 0; ; i++) {
		if ('0' <= str[i] && str[i] <= '9') {
			push_c(buf, str[i]);
		}
		else {
			cs = pushStack(cs, buf);
			memset(buf, '\0', sizeof(buf));
			push_c(buf, str[i]);
			cs = pushStack(cs, buf);
			memset(buf, '\0', sizeof(buf));
		}
		if (str[i] == '\0') {
			break;
		}
	}

	memset(buf, '\0', sizeof(buf));
	charStack* cs2;
	cs2 = createStack();
	// �擪����
	charStack* temp;
	cs = cs->first;
	cs = cs->next;
	temp = cs->first;
	
	// * / ����ւ�
	while(1) {
		cs = popStack(cs, buf);
		if (buf[0] == '*' || buf[0] == '/') {
			if (cs->next != NULL) {
				cs2 = pushStack(cs2, cs->str);
				cs = cs->next;
			}
		}
		cs2 = pushStack(cs2, buf);
		memset(buf, '\0', sizeof(buf));
		if (cs->next == NULL) {
			break;
		}
	}

	// ���
	freeStack(cs);
	
	memset(buf, '\0', sizeof(buf));
	charStack* cs3;
	charStack* temp2;
	cs3 = createStack();
	// �擪����
	cs2 = cs2->first;
	cs2 = cs2->next;
	temp = cs2;
	temp2 = cs2->first;

	// + - ����ւ�
	while (1) {
		char c[CHAR_SIZE];
		memset(c, '\0', sizeof(c));

		if (cs2 == NULL) {
			break;
		}
		cs2 = popStack(cs2, buf);
		if (buf[0] == '+' || buf[0] == '-') {
			while (1) {
				temp = cs2;
				if (temp != NULL) {
					cs2 = popStack(temp, c);
				}
				if (temp == NULL) {
					break;
				}
				if (c[0] == '+' || c[0] == '-') {
					cs2 = temp;
					break;
				}
				cs3 = pushStack(cs3, c);
				memset(c, '\0', sizeof(c));
			}
		}
		cs3 = pushStack(cs3, buf);
		memset(buf, '\0', sizeof(buf));
	}

	// ���
	cs2 = temp2;
	freeStack(cs2);
	memset(buf, '\0', sizeof(buf));
	cs3 = cs3->first;
	temp = cs3->next;

	while (1) {
		if (temp == NULL) {
			break;
		}
		temp = popStack(temp, buf);
		printf("%s ", buf);
		memset(buf, '\0', sizeof(buf));
	}
	printf("\n");

	// ���
	cs3 = cs3->first;
	freeStack(cs3);

	printf("\n\n�I��\n\n");

	return 0;
}

void freeStack(charStack* cs)
{
	if (cs == NULL) {
		return;
	}
	charStack* temp;
	cs = cs->first;
	temp = cs->next;
	free(cs);
	while (1) {
		if (temp == NULL) {
			break;
		}
		cs = temp;
		temp = cs->next;
		if (temp != NULL) {
			free(cs);
		}
	}
}

charStack* createStack()
{
	charStack* cs;
	cs = (charStack*)malloc(sizeof(charStack));
	if (cs == NULL) {
		printf("ERROR  createStack\n");
		exit(1);
	}
	cs->before = NULL;
	cs->next = NULL;
	cs->first = cs;
	cs->last = cs;
	memset(cs->str, '\0', sizeof(cs->str));
	return cs;
}

charStack* pushStack(charStack* cs, char buf[CHAR_SIZE])
{
	charStack* temp;
	temp = (charStack*)malloc(sizeof(charStack));
	if (temp == NULL) {
		printf("ERROR  pushStack\n");
		exit(1);
	}
	cs->next = temp;
	temp->first = cs->first;
	temp->before = cs;
	temp->next = NULL;
	temp->last = temp;
	memset(temp->str, '\0', sizeof(temp->str));
	sprintf(temp->str, "%s", buf);
	return temp;
}

charStack* popStack(charStack* cs, char buf[CHAR_SIZE]) 
{
	sprintf(buf, "%s", cs->str);
	charStack* temp;
	temp = cs->next;
	return; temp;
}

void push_c(char buf[CHAR_SIZE], char c)
{
	sprintf(buf, "%s%c", buf, c);
}