#include <stdio.h>
typedef char String[1024];

int main(void) {
	
	String strInput="";
	int inum = 0;

	typedef struct{
		int iEnglish;
		int iMath;
		int iHistory;
		int iScience;
		int iGeography;
		double dAvg;
	}tagTestScore;

	tagTestScore studentSco={0,0,0,0,0,0};

	printf("英語の点数を入力してください : ");
	scanf("%s",strInput);
	studentSco.iEnglish = atoi(strInput);
	printf("\n数学の点数を入力してください : ");
	scanf("%s",strInput);
	studentSco.iMath = atoi(strInput);
	printf("\n歴史の点数を入力してください : ");
	scanf("%s",strInput);
	studentSco.iHistory = atoi(strInput);
	printf("\n科学の点数を入力してください : ");
	scanf("%s",strInput);
	studentSco.iScience = atoi(strInput);
	printf("\n地理の点数を入力してください : ");
	scanf("%s",strInput);
	studentSco.iGeography = atoi(strInput);

	int iSum = studentSco.iEnglish 
			 + studentSco.iMath
			 + studentSco.iHistory
			 + studentSco.iScience
			 + studentSco.iGeography;

	studentSco.dAvg = (double)iSum/5;
	printf("\n5科目の合計点 : %d\n", iSum);
	printf("5科目の平均点 : %.1f", studentSco.dAvg);

	return 0;

}
