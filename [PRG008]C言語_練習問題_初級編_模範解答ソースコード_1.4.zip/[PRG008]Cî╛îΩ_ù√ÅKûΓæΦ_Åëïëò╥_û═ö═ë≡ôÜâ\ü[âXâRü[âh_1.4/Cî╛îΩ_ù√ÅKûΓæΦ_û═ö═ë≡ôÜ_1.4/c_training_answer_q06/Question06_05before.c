#include <stdio.h>

int main(void) {

	int iEnglish = 88;
	int iMath = 63;
	int iHistory = 54;
	int iScience = 76;
	int iGeography = 45;

	int iSum = iEnglish + iMath + iHistory + iScience + iGeography;

	printf("5科目の合計点 : %d点\n", iSum);
	printf("5科目の平均点 : %.1f点\n", (double)iSum/5);

	return 0;

}
