#include <stdio.h>

typedef char String[1024];
int main(void) {

	typedef struct{
		String name;
		int age;
	}tagCat;

	tagCat cat = { "コタロウ",7 };
//	以下でも可
//	tagCat cat = { 
//		.name = "コタロウ",
//		.age = 7 
//	};

	printf("名前は%sです\n", cat.name);
	printf("年齢は%d歳です\n", cat.age);

	return 0;
}