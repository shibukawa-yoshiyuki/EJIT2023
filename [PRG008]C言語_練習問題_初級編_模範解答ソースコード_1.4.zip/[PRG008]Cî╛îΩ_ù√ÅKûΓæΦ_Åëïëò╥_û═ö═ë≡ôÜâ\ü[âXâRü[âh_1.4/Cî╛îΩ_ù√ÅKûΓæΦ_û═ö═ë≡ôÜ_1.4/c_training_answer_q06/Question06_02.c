#include <stdio.h>

typedef char String[1024];
int main(void) {

	typedef struct{
		String name;
		int age;
		double height;
		double weight;
		String favoriteFood;
	}tagCat;

	tagCat cat = { "コタロウ",7,52.3,4.8,"ささみ" };
//	以下でも可
//	tagCat cat = { 
//		.name = "コタロウ",
//		.age = 7 
//		.height = 52.3,
//		.weight = 4.8,
//		.favoriteFood = "ささみ" 
//	};

	printf("名前は%sです\n", cat.name);
	printf("年齢は%d歳です\n", cat.age);
	printf("身長は%.1fcmです\n", cat.height);
	printf("体重は%.1fkgです\n", cat.weight);
	printf("好きな食べ物は%sです\n", cat.favoriteFood);

	return 0;
}