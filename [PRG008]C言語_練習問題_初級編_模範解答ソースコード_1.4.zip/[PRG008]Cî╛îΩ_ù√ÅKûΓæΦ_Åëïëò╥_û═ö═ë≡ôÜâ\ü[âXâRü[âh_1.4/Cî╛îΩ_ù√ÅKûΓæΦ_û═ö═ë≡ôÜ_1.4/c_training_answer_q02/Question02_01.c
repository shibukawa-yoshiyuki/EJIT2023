#include <stdio.h>

int main(void) {

	printf("%d",10);
	printf("桁\n");
	printf("%.1f", 30.8);
	printf("回\n");

	return 0;
}