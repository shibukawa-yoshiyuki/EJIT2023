#include <stdio.h>

int main(void)
{
	const double PI = 3.14;

	printf("円周率は、%.2f\n", PI);
	return 0;
}