#include <stdio.h>

int main(void) {

	int inum = 12;
	printf("最初の値は、%d\n",inum);

	inum = 20;
	printf("変更後の値は、%d\n",inum);

	return 0;
}