#include <stdio.h>

int main(void) {
	int inum = 50;
	printf("変数の値は%dです\n", inum);

	double dnum = 10.5;
	printf("変数の値は%.1fです\n", dnum);

	return 0;
}