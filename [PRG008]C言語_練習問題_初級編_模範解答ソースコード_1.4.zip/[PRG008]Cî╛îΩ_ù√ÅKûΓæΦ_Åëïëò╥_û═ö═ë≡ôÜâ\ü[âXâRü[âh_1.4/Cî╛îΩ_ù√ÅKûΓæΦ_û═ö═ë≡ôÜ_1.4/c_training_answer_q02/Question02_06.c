#include <stdio.h>

int main(void) {

	char cvar;
	short shvar;
	int ivar;
	long lvar;
	float fvar;
	double dvar;

	printf("sizeof char:%d\n",sizeof(cvar));
	printf("sizeof short:%d\n",sizeof(shvar));
	printf("sizeof int:%d\n",sizeof(ivar));
	printf("sizeof long:%d\n",sizeof(lvar));
	printf("sizeof float:%d\n",sizeof(fvar));
	printf("sizeof double:%d\n",sizeof(dvar));
	return 0;
}
