#include <stdio.h>

typedef char String[1024];
int main(void) {

	int inum = 12;
	double dnum = 20.58;
	String str = "こんにちは";

	printf("%d\n", inum);
	printf("%.2f\n", dnum);
	printf("%s\n", str);

	return 0;
}