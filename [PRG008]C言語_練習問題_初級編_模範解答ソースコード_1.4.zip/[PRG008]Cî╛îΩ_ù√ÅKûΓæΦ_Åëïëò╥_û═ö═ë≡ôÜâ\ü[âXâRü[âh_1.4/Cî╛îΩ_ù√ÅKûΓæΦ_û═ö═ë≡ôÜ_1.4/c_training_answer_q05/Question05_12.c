#include <stdio.h>

int main(void) {

	int max=8;
	
	for (int i = 0; i < max; i++) {
		for (int j = 0; j <max; j++) {
			if (i == j || i+j==max-1) {
				printf("*");
			}
			else {
				printf(" ");
			}
		}
		printf("\n");
	}

	return 0;

}
