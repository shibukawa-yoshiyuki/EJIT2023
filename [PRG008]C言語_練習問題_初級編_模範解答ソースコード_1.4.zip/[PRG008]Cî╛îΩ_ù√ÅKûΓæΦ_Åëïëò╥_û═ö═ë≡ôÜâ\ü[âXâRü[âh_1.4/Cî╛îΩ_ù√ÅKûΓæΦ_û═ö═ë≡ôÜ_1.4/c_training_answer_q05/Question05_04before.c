#include <stdio.h>

int main(void) {
	for (int i = 1; i <= 10; i++) {
//　----修正対象ここから----
		printf("%d回目の処理です\n",i);
//　----修正対象ここまで----
	}

	printf("処理を終了します");

	return 0;
}
