#include <stdio.h>

int main(void) {

	for (int i = 1; i <= 8; i++) {
		for (int j = 8; j > i; j--) {
			printf(" ");
		}
		for (int j = 1; j <= 2 * i - 1; j++) {
			if (i % 2 == 0) {
				printf("@");
			}
			else {
				printf("*");
			}
		}
		printf("\n");
	}

	return 0;

}
