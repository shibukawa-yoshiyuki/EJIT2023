#include <stdio.h>

int main(void) {
	printf("九九を表示します\n");

	for (int i = 1; i <= 9; i++) {
			printf("%dの段\t",i);
		for (int j = 1; j <= 9; j++) {
			printf("%d",i * j);
			printf("\t");
		}
		printf("\n");
	}
	return 0;

}
