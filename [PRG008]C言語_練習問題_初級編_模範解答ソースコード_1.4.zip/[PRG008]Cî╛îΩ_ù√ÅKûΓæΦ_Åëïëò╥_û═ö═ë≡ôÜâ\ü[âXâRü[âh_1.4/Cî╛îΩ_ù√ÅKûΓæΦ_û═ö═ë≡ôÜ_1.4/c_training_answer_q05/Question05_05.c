#include <stdio.h>

int main(void) {
	for (int i = 1; i <= 10; i++) {
		if(i%2==1){
			continue;
		}
		printf("%d回目の処理です\n",i);
	}

	printf("処理を終了します");

	return 0;
}
