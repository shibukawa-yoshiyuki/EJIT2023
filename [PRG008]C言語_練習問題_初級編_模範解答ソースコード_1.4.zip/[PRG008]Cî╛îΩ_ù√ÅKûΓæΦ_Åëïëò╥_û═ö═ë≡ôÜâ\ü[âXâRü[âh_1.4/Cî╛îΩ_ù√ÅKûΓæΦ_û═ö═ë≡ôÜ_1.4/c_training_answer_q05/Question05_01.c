#include <stdio.h>
#include <stdlib.h>

typedef char String[1024];
int main(void) {

	String strInput="";
	int inum = 0;

	printf("入力された月の日数を表示します。\n");
	printf("1～12の数値を入力してください。\n");
	scanf("%s",strInput);
	inum = atoi(strInput);

//　----修正対象ここから----
	switch(inum) {
		case 2:
			printf("2月は28日もしくは29日です。");
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			printf("%d月は30日です。",inum);
			break;
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			printf("%d月は31日です。",inum);
			break;
		default:
			printf("%d月はありません。",inum);
			break;
	}
//　----修正対象ここまで----	
	return 0;
}
