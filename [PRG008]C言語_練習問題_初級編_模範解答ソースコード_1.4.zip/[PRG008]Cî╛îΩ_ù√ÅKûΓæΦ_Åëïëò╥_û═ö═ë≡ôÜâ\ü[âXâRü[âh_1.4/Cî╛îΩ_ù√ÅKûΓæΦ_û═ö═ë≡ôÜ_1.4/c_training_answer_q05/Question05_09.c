#include <stdio.h>

typedef char String[1024];
int main(void) {
	
	String strInput="";
	int iTate = 0;
	int iYoko = 0;

	printf("縦の数：1～9の値を入力してください\n");
	scanf("%s",strInput);
	iTate = atoi(strInput);
	printf("横の数：1～9の値を入力してください\n");
	scanf("%s",strInput);
	iYoko = atoi(strInput);

	printf("縦：%d  横：%d の四角形を表示します。\n",iTate,iYoko);

	for (int i = 0; i < iTate; i++) {
		for (int j = 0; j < iYoko; j++) {
			printf("*");
		}
		printf("\n");
	}

	return 0;

}
