#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef char String[1024];
int main(void) {

	String strInput="";
	int inum = 0;
	int iRandnum=0;
	int iCnt=0;

	srand(time(NULL));
	iRandnum = rand() % 10+1;

	do{
		iCnt++;
		printf("%d 回目のチャレンジ！\n",iCnt);
		printf("1～10の数値を入力してください\n");
		scanf("%s",strInput);
		inum = atoi(strInput);
	}while(iRandnum!=inum);
	printf("あたり!!：値は %d \n",iRandnum);
	printf("チャレンジ回数は、%d でした",iCnt);
	return 0;
}