#include <stdio.h>
#include <stdbool.h>

typedef char String[1024];
int main(void) {
	
	const int TRUE=1;
	String strInput="";
	int inum = 0;

	while(TRUE){
		printf("5以上の数値を入力してください\n");
		scanf("%s",strInput);
		inum = atoi(strInput);
		if (inum < 5) {
			continue;
		}else{
			printf("5以上の数値が入力されました\n処理を終了します");
			break;
		}
	}
	return 0;

}