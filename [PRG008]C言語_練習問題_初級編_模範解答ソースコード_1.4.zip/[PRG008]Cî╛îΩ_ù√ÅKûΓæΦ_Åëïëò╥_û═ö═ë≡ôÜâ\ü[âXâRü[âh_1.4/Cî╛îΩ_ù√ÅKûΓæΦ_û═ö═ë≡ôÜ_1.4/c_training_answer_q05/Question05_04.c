#include <stdio.h>

int main(void) {
	for (int i = 1; i <= 10; i++) {
		printf("%d回目の処理です\n",i);
		if(i == 5){
			break;
		}
	}

	printf("処理を終了します");

	return 0;
}
