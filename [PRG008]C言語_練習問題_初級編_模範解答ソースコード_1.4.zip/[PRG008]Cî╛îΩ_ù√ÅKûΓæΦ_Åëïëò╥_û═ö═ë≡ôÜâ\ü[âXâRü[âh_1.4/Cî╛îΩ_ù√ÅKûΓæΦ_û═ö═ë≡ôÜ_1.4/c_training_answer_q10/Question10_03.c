#include <stdio.h>
int main()
{
	char cmoji[8] = "ABCDEFG";
	int i=0;
	int imojicnt = 8;
	
   	printf( "前から順:");

	for( i = 0 ; i < imojicnt ; i++ ){
    	printf( "%c ", *(cmoji + i) );
	}
   	printf( "\n後から順:");
	for( i = imojicnt-2 ; i >= 0 ; i-- ){
    	printf( "%c ", *(cmoji + i) );
	}
}