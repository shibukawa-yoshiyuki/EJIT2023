#include <stdio.h>
#include <stdlib.h>

typedef char String[1024];

int main() {
	int *pArray=NULL;
	int inum1;
	int inum2;
	int iarrayPoint=0;

	pArray = (int *)malloc(sizeof(int) * 9 * 9);

	if (pArray == NULL) {
		printf("ヒープ確保に失敗しました\n");
	}else {
		for (int i = 1; i <= 9; i++) {
			for (int j = 1; j <= 9; j++) {
				pArray[iarrayPoint]=i * j;
				iarrayPoint++;
			}
		}
	}	
	printf("2つの数字をかけた値をメモリから取り出して表示します。\n");
	printf("1つ目の数字 1～9の数字を入力してください: ");
	String strInput="";
	scanf("%s",strInput);
	inum1 = atoi(strInput);
	printf("2つ目の数字 1～9の数字を入力してください: ");
	scanf("%s",strInput);
	inum2 = atoi(strInput);
	
	if(inum1==1){
		iarrayPoint=inum2-1;
	}else if(inum2==1){
		iarrayPoint=(inum1-1)*8+(inum1-1);
	}else{
		iarrayPoint=(inum1-1)*8+(inum1-1)+inum2-1;
	}
	printf("アドレス番地: %p+%d\n",pArray,iarrayPoint);
	printf("%d×%d=%d",inum1,inum2,pArray[iarrayPoint]);

	free(pArray);
	pArray=NULL;

	return 0;
}
