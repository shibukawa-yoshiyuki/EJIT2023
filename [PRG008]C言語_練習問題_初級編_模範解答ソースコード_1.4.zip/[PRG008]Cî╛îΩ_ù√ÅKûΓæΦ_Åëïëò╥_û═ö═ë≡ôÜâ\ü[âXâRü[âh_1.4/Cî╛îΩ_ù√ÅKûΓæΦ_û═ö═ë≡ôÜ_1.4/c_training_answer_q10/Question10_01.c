#include <stdio.h>
int main()
{
	int inum[3] ={1,2,3};

	int *pnum1;
	int *pnum2;
	int *pnum3;


	pnum1=&inum[0];
	pnum2=&inum[1];
    pnum3=&inum[2];

	
	printf("\n試してみよう！\n");
    printf("pnum2+1のアドレス番地 pnum2+1\t= %p\n",(pnum2+1));
    printf("pnum2+1の値 *(pnum2+1)\t\t= %d\n",*(pnum2+1));
    printf("pnum2+1の値 pnum2[0+1]\t\t= %d\n\n",pnum2[0+1]);
    printf("pnum2のアドレス番地 pnum\t= %p\n",pnum2);
    printf("pnum2の値 *(pnum2)\t\t= %d\n",*pnum2);
    printf("pnum2の値 pnum2[0]\t\t= %d\n\n",pnum2[0]);
    printf("pnum2-1のアドレス番地 pnum2-1\t= %p\n",(pnum2-1));
    printf("pnum2-1の値 *(pnum2-1)\t\t= %d\n",*(pnum2-1));
    printf("pnum2-1の値 pnum2[0-1]\t\t= %d\n\n",pnum2[0-1]);

	return 0;
}