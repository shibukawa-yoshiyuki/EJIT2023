#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void memfree(char **ppmem,int *cnt){
	/* 各要素（ポインタ）のメモリ解放 */
	for (int i = 0; i < *cnt; i++){
		 free(ppmem[i]);		
	}
	/* メモリ解放 */
	free(ppmem); 
}

int main(void) {

	char str[256]; 
	char **ppmem;	/* char型ポインタへのポインタtableを宣言 */
	int cnt;

	/* 入力する文字列の数を入力 */
	printf("入力する行数を入れてください: ");
	scanf("%d", &cnt);

	/* 文字列の数分のchar型ポインタを格納するためのメモリを確保 */
	ppmem = (char **)malloc(sizeof(char *) * cnt);
	if (ppmem==NULL) {
		  printf("メモリ確保に失敗しました\n");
		 return 1;
	 }

	// メモリ初期化
	memset(ppmem,'\0',sizeof(char *) * cnt);
	printf("\n-----------------------------\n");
	printf("アドレス番地ppmem:%p\n",ppmem);
	printf("アドレス番地*ppmem:%p\n",*ppmem);
	printf("確保サイズ:%d",sizeof(char *) * cnt);
	printf("\n-----------------------------\n");
	
	for (int i = 0; i < cnt; i++) {
		printf("%d行目 #: ", i+1);
		scanf("%s", str); 
		ppmem[i]=(char *)malloc(sizeof(char)*(strlen(str)+1));
		if (ppmem[i]==NULL) {
			  printf("メモリ確保に失敗しました\n");
			  memfree(ppmem,&cnt);
			  return 1;
		}
		strcpy(ppmem[i], str); 
	}
	printf("\n-----------------------------\n");
	printf("入力された値の表示 入力順\n");
	// 入力値を表示する
	for (int i = 0; i < cnt; i++){
		 printf("%d行目%s \t3番目の文字:%c\t: メモリのサイズ:%d \t:アドレス番地:%p\n",
		 	i+1, ppmem[i],ppmem[i][2], sizeof(char)*(strlen(ppmem[i])+1),ppmem[i]);
	}
	printf("-----------------------------\n");
	printf("入力された値の表示 逆順\n");
	// 入力値を表示する
	for (int i = cnt-1; i >= 0 ; i--){
		 printf("%d行目%s \t4番目の文字:%c\t: メモリのサイズ:%d \t:アドレス番地:%p\n",
		 	i+1, ppmem[i],ppmem[i][3], sizeof(char)*(strlen(ppmem[i])+1),ppmem[i]);
	}
	printf("-----------------------------\n");
	memfree(ppmem,&cnt);
	return 0;
}

