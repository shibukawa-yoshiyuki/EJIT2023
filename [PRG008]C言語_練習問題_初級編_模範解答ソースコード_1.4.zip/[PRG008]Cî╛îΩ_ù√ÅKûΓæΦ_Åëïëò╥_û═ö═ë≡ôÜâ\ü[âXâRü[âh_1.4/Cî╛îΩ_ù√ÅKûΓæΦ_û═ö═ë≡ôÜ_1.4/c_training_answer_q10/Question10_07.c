#include <stdio.h>
 
int main(void)
{
    char buf[10];
    int ibufsize = 10;
    
    memset(buf,'0',ibufsize*sizeof(char));

    printf("---bufを0で初期化---\n");
	for(int i = 0;i < ibufsize;i++){
		printf("buf[%d]=%c ",i,buf[i]);
		if(i==4){
			printf("\n");
		}
	}
    
	memset(buf+3,'1',sizeof(char)*3);
    printf("\n\n---buf+3から3文字を1で初期化---\n");
	for(int i = 0;i < ibufsize;i++){
		printf("buf[%d]=%c ",i,buf[i]);
		if(i==4){
			printf("\n");
		}
	}

	memset(buf+7,'A',sizeof(char)*2);
    printf("\n\n---buf+7から2文字をAで初期化---\n");
	for(int i = 0;i < ibufsize;i++){
		printf("buf[%d]=%c ",i,buf[i]);
		if(i==4){
			printf("\n");
		}
	}

    return 0;

}
