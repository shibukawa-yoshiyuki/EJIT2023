#include <stdio.h>

int main(void) {

	int iArray1[5] = {12,34,56,78,90};
	int iArray2[5] = {12,34,56,78,90};
	int *pArray;
	pArray = &iArray1[0];

	int iArraySize = 5;
	
	printf("\n<<< iArray1、iArray2、pArrayのアドレス番地を表示 >>>\n");
	printf("iArray1=%p ,iArray2=%p ,pArray=%p\n",
			&iArray1,&iArray2,pArray);
	printf("\n<<< iArray1、iArray2、pArrayの値を表示 >>>\n");
	for(int i = 0;i < iArraySize; i++){
		printf("iArray1[%d]=%d ,iArray2[%d]=%d ,*(pArray+%d)=%d\n",
			i,iArray1[i],i,iArray2[i],i,*(pArray+i));
	}	
	
	printf("\n---iArray1とiArray2を等値比較(==演算子)---\n");
	if (iArray1 == iArray2) {
		printf(" iArray1:iArray2 = 等しい\n");
	}else{
		printf(" iArray1:iArray2 = 等しくない\n");
	}
	
	printf("\n---iArray1とpArrayを等値比較(==演算子)---\n");
	if (iArray1 == pArray) {
		printf(" iArray1:pArray = 等しい\n");
	}else{
		printf(" iArray1:pArray = 等しくない\n");
	}
	
	printf("\n---iArray2とpArrayを等値比較(==演算子)---\n");
	if (iArray2 == pArray) {
		printf(" iArray2:pArray = 等しい\n");
	}else{
		printf(" iArray2:pArray = 等しくない\n");
	}
	int result;
	printf("\n---iArray1とiArray2を等価比較(memcmp)---\n");
	result = memcmp(iArray1, iArray2, iArraySize*sizeof(int));
	if (result == 0) {
		printf(" iArray1:iArray2 = 等しい\n");
	}else{
		printf(" iArray1:iArray2 = 等しくない\n");
	}

	printf("\n---iArray1とpArrayを等価比較(memcmp)---\n");
	result = memcmp(iArray1, pArray, iArraySize*sizeof(int));
	if (result == 0) {
		printf(" iArray1:pArray = 等しい\n");
	}else{
		printf(" iArray1:pArray = 等しくない\n");
	}

	printf("\n---iArray2とpArrayを等価比較(memcmp)---\n");
	result = memcmp(iArray2, pArray, iArraySize*sizeof(int));
	if (result == 0) {
		printf(" iArray2:pArray = 等しい\n");
	}else{
		printf(" iArray2:pArray = 等しくない\n");
	}
	return 0;
}