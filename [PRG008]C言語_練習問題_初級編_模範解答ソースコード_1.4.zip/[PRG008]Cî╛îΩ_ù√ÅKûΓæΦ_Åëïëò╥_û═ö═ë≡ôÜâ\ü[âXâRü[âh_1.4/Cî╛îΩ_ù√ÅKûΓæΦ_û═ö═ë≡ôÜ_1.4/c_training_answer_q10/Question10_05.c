#include <stdio.h>
int main(void) {

	typedef struct{
		int iSubNum;
	}tagTestSubStruct;

	typedef struct{
		char chMoji;
		int iNum;
		tagTestSubStruct subStruct;
	}tagTestStruct;

	tagTestStruct structOrg;
	tagTestStruct structCpy;

	structOrg.chMoji = 'A';
	structOrg.iNum = 0;
	structOrg.subStruct.iSubNum = 9;
	structCpy.chMoji = 'Z';
	structCpy.iNum = 5;
	structCpy.subStruct.iSubNum = 4;
	
	printf("---コピー前---\n");
	printf(" <<<コピー元>>>\n");
	printf("structOrg.chMoji\t\t %c\n",structOrg.chMoji );
	printf("structOrg.iNum:\t\t\t %d\n", structOrg.iNum);
	printf("structOrg.subStruct.iSubNum:\t %d\n", structOrg.subStruct.iSubNum);
	printf("structOrgアドレス番地:\t %p\n", &structOrg);
	printf(" <<<コピー先>>>\n");
	printf("structCpy.chMoji\t\t %c\n",structCpy.chMoji );
	printf("structCpy.iNum:\t\t\t %d\n", structCpy.iNum);
	printf("structCpy.subStruct.iSubNum:\t %d\n", structCpy.subStruct.iSubNum);
	printf("structCpyアドレス番地:\t %p\n", &structCpy);

	memcpy(&structCpy, &structOrg, sizeof(structOrg));

	printf("---コピー後---\n");
	printf(" <<<コピー元>>>\n");
	printf("structOrg.chMoji\t\t %c\n",structOrg.chMoji );
	printf("structOrg.iNum:\t\t\t %d\n", structOrg.iNum);
	printf("structOrg.subStruct.iSubNum:\t %d\n", structOrg.subStruct.iSubNum);
	printf("structOrgアドレス番地:\t %p\n", &structOrg);
	printf(" <<<コピー先>>>\n");
	printf("structCpy.chMoji\t\t %c\n",structCpy.chMoji );
	printf("structCpy.iNum:\t\t\t %d\n", structCpy.iNum);
	printf("structCpy.subStruct.iSubNum:\t %d\n", structCpy.subStruct.iSubNum);
	printf("structCpyアドレス番地:\t %p\n", &structCpy);

	return 0;
}
