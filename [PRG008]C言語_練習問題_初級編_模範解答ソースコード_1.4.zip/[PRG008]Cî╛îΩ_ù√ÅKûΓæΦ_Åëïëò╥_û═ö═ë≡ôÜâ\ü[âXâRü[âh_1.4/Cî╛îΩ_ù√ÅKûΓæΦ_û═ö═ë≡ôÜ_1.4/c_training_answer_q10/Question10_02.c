#include <stdio.h>
int main()
{
	char cmoji[6] = "ABCDE";
	char *pmoji;
	pmoji = cmoji;
	int i = 0;
	for(int i=0;i < 5;i++){
	    printf("*pmoji: %c\tcmoji[%d]: %c\tpmoji(アドレス番号): %p\n",*pmoji,i,cmoji[i],pmoji);
		pmoji++;
	}
	
	return 0;
}