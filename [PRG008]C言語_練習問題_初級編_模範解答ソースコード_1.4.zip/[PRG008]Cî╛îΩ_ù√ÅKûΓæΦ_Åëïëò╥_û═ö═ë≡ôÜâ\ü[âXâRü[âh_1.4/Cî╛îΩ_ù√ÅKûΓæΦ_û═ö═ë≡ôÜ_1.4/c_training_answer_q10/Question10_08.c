#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int * pArray = NULL;
    int i;
    const int ARRAY_CNT=500;

    pArray = (int *)malloc(sizeof(int) * ARRAY_CNT);
    if (pArray == NULL){
        printf("ERROR");
        return 0;
    }

    for (i = 0 ; i < ARRAY_CNT ; i++){
        pArray[i] = i;
    }

    for (i = ARRAY_CNT - 10; i < ARRAY_CNT ; i++){
        printf("pArray[%d] = %d\n", i, pArray[i]);
    }

    free(pArray);
    pArray = NULL;

    return 0;
}