#include <stdio.h>

int main(void) {

	int iNumber = 9 ;
//	int iNumber = 10;

	printf("処理を開始します。\n");
	if (iNumber >= 10) {
		printf("iNumberの値は10以上です。\n");
	}else{
		printf("iNumberの値は10未満です。\n");
	}
	
	printf("\n処理を終了します。");

	return 0;

}