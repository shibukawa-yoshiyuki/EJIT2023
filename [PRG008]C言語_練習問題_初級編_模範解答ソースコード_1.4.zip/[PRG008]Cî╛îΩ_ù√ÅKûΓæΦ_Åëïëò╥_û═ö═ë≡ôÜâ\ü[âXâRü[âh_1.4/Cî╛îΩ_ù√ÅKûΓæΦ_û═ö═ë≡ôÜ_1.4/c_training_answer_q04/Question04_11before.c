#include <stdio.h>
#include <stdlib.h>

typedef char String[1024];
int main(void) {
	String strInput="";
	int inum = 0;
	
	printf("一桁の数値を入力してください\n");
	scanf("%s",strInput);
	inum = atoi(strInput);

//　----修正対象ここから----
	if (inum == 1) {
		printf("1か2が入力されました\n");
	}else if (inum == 2) {
		printf("1か2が入力されました\n");
	}else {
		printf("1と2以外が入力されました\n");
	}

//　----修正対象ここまで----
	return 0;
}
