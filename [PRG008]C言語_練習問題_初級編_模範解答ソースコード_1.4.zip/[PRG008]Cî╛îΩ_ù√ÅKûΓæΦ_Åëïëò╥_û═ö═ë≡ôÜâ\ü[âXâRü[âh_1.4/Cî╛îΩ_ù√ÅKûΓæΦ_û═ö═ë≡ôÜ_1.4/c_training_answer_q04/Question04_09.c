#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {

	srand(time(NULL));
	int iRandnum;
	//0～5の乱数より-2することで-2～3の値にする
	iRandnum = rand() % 6-2;
	if (iRandnum == 2) {
		printf("値は 2 です\n");
	}else if (iRandnum >= 1) {
		printf("値は 1 以上です\n");
	}else {
		printf("値はそれ以外の数値です\n");
	}

	printf("\n値は %d でした。処理を終了します\n",iRandnum);

	return 0;

}