#include <stdio.h>
#include <stdlib.h>

typedef char String[1024];
int main(void) {
	String strInput="";
	int inum1 = 0;
	int inum2 = 0;
	
	printf("1か2を入力してください\n");
	scanf("%s",strInput);
	inum1 = atoi(strInput);

	printf("もう一度1か2を入力してください\n");
	scanf("%s",strInput);
	inum2 = atoi(strInput);

//　----修正対象ここから----
	if (inum1 == 1) {
		if (inum2 == 1) {
			printf("1が2回入力されました\n");
		}
	}
//　----修正対象ここまで----
	return 0;
}