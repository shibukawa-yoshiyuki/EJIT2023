#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

int main(void) {

	srand(time(NULL));

	int iRandnum;
	bool bFlag = false;
		
	iRandnum = rand() % 100;
	if (iRandnum>=50) {
		bFlag = true;
	}else {
		bFlag = false;
	}
	
	printf("値は%d\t判断結果は、",iRandnum);
	
	if (!bFlag) {
		printf("50未満でした\n");
	}else {
		printf("50以上でした\n");
	}

	return 0;
}
