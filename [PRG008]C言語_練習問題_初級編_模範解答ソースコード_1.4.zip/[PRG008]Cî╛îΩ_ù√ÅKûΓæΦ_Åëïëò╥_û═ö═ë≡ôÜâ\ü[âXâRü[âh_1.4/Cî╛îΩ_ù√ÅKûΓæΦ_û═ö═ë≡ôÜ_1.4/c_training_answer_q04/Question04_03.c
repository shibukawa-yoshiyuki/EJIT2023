#include <stdio.h>

int main(void) {

	int iNumber = 10;

	printf("1回目：");
	if (iNumber >= 10) {
		printf("iNumberの値は10以上です。\n");
	}
	iNumber--;
	printf("iNumberをデクリメントしました。\n");

	printf("2回目：");
	if (iNumber >= 10) {
		printf("iNumberの値は10以上です。\n");
	}
	printf("\n処理を終了します。");

	return 0;

}