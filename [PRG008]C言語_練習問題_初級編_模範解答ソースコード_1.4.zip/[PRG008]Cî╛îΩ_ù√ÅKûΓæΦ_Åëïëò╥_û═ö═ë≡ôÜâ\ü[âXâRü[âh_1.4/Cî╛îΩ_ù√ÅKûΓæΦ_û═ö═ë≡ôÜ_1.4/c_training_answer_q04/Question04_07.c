#include <stdio.h>
#include <stdbool.h>

int main(void) {

//	bool flg=false;
	bool flg=true;
	
	printf("処理を開始します。\n");
	if (flg) {
		printf("1回目:flgの値はtrueです。\n");
	}else{
		printf("1回目:flgの値はfalseです。\n");
	}
	
	if (!flg) {
		printf("2回目:!flgの値はtrueです。\n");
	}else{
		printf("2回目:!flgの値はfalseです。\n");
	}
	printf("\n処理を終了します。");

	return 0;

}
