#include <stdio.h>
#include <stdbool.h>

typedef char String[1024];
int main(void) {
	
	String strInput="";
	int inum = 0;
	bool bErrFlag = false;//5未満の時にtrue

	while(!bErrFlag){
		printf("5以上の数値を入力してください\n");
		scanf("%s",strInput);
		inum = atoi(strInput);
		if (inum < 5) {
			bErrFlag = false;
		}else{
			printf("5以上の数値が入力されました\n処理を終了します");
			bErrFlag = true;
		}
	}
	return 0;

}