#include <stdio.h>

int main(int args,char **argv){
	int i=0;

   	printf( "前から順:");

	for( i = 1 ; i < args ; i++ ){
    	printf( "%c ", *(argv[i]) );
	}
   	printf( "\n後から順:");
	for( i = args-1 ; i > 0 ; i-- ){
    	printf( "%c ", *(argv[i]) );
	}
	return 0;
}