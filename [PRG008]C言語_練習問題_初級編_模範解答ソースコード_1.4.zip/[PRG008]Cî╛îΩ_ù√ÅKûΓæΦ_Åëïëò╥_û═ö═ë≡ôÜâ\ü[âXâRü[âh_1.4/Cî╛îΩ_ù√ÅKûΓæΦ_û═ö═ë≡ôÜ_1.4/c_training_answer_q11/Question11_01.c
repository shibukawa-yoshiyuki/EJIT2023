#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void)
{
	char* str = (char*)malloc(256);
	strcpy(str, "HelloWorld");
	int len;
	len = strlen(str);
	printf("文字列%sの長さ%d\n", str, len);
	printf("----文字を追加----\n");
	str[len] = '!';
	str[len + 1] = '\0';
	len = strlen(str);
	printf("文字列%sの長さ%d\n", str, len);
	free(str);
	return 0;
} 