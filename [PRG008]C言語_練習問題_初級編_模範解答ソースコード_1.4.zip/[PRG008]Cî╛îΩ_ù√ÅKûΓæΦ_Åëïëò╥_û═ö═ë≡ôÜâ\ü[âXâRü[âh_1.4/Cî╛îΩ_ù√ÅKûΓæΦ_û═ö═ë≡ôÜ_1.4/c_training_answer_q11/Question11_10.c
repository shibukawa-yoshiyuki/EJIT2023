#include <stdio.h>

int main(void) {
	
	int iTate = 0;
	int iYoko = 0;
	char moji1 = '*';
	char moji2 = '*';

	printf("縦と横の数、表示する記号を2種類入力すると、四角形が表示されます。\n");
	printf("縦の数、横の数、記号を次の形式で入力してください\n");
	printf("入力形式: [1～9],[1～9],[@#$%&*-],[@#$%&*-]\n");
	printf("入力例: 4,9,@,-\n\n");
	scanf("%d,%d,%c,%c",&iTate,&iYoko,&moji1,&moji2);

	printf("\n縦: %d  横: %d の四角形を表示します。\n",iTate,iYoko);

	for (int i = 0; i < iTate; i++) {
		for (int j = 0; j < iYoko; j++) {
			if((i+j)%2==0){
				printf("%c",moji1);
			}else{
				printf("%c",moji2);
			}
		}
		printf("\n");
	}

	return 0;

}
