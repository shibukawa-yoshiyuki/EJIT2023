#include <stdio.h>
#include <string.h> 

typedef char String[1024];

int main(void)
{
	String strInput="";
	printf("文字列を入力してください:");
	scanf("%s",strInput);

	int len;
	len = strlen(strInput);
	printf("\n入力された文字列: %s\n", strInput);
	printf("文字列の長さ: %d\n", len);

	return 0;
}
