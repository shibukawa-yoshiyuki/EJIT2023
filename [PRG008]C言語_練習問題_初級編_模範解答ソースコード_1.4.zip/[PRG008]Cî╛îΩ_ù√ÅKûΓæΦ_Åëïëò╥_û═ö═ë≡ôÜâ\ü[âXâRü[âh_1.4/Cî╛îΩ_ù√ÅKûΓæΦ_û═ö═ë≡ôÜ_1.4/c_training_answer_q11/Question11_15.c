#include <stdio.h>

int main(int args,char **argv){
   	printf( "<<< main関数の引数 >>>\n");
	printf( "第1引数:args=%d\n",args);
	printf( "第2引数:argvの値 アドレス番地(argv)=%p\n",argv);
	printf( "第2引数:argvの値 アドレス番地(*argv)=%p\n",*argv);
   	printf( "\n<<< コマンドライン引数の表示 >>>\n");
	for(int i=0 ; i < args ; i++ ){
    	printf( "---%d番目---\n",i);
    	printf( "アドレス番地: *(argv+%d)=%p,  argv[%d]=%p\n",i,*(argv+i),i,argv[i]);
    	printf( "値: argv[%d]=%s\n", i,argv[i] );
    	printf( "長さ: strlen(argv[%d])=%d\n", i,strlen(argv[i]) );
	}
	
}