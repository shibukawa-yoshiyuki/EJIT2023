#include <stdio.h>

double calcParc(int cntMoji,int len){
	return ((double)cntMoji/(double)len)*100;
}

int main(int args,char **argv){
	
	char *pArray=NULL;

	pArray = (char *)malloc(sizeof(*argv));
	memset(pArray,'\0',sizeof(char *) * args);


	if (pArray == NULL) {
		printf("ヒープ確保に失敗しました\n");
	}else {
		for(int i=1;i<args;i++){
			strcat(pArray,argv[i]);

			strcat(pArray," "); 
		}
	}	

	int len =strlen(pArray);
	int cntMoji[5]={0,0,0,0,0};

	if(len > 0){
		printf("\nコマンドライン引数に数字、英字、記号がそれぞれ何個ずつあるかを表示します\n");
		
		for(int i=0;i<len;i++){
			if('0'<= pArray[i] && pArray[i]<= '9'){
				cntMoji[0]++;
			}else if('A'<= pArray[i] && pArray[i]<= 'Z'){
				cntMoji[1]++;
			}else if('a'<= pArray[i] && pArray[i]<= 'z'){
				cntMoji[2]++;
			}else{
				if(pArray[i]==' '){
					cntMoji[3]++;
				}else{
					cntMoji[4]++;
				}
			}
		}
		printf("\nコマンドライン文字列:%s",pArray);
		printf("\n全文字数:%d",len);
		printf("\n数字    :%4d\t%5.1f%%",cntMoji[0],calcParc(cntMoji[0],len));
		printf("\n英大文字:%4d\t%5.1f%%",cntMoji[1],calcParc(cntMoji[1],len));
		printf("\n英小文字:%4d\t%5.1f%%",cntMoji[2],calcParc(cntMoji[2],len));
		printf("\n空白文字:%4d\t%5.1f%%",cntMoji[3],calcParc(cntMoji[3],len));
		printf("\nその他  :%4d\t%5.1f%%",cntMoji[4],calcParc(cntMoji[4],len));
	}else{
		printf("\nコマンドライン引数に文字列がありません\n");
	}
	
	free(pArray);
	pArray=NULL;

	return 0;
}