#include <stdio.h>

int main(void) {

	int num = 0;

	printf("整数を入力してください。\n");
	scanf_s("%d", &num);

	if (num % 2 == 0) {
		printf("%dは偶数です。",num);
	}else {
		printf("%dは奇数です。", num); 
	}

	return 0;

}
