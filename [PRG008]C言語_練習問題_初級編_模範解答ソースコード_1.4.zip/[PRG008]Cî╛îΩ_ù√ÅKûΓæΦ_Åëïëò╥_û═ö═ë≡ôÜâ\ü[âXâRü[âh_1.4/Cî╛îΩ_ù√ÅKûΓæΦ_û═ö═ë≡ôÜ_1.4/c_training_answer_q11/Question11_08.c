#include <stdio.h>

int main(void) {

	int inum = 0;
	printf("入力された段の九九を表示します\n");
	printf("1～9の数値を入力してください\n");
	scanf("%d",&inum);

	printf("%dの段\t",inum);
	for (int j = 1; j <= 9; j++) {
		printf("%d",inum * j);
		printf("\t");
	}
	return 0;

}
