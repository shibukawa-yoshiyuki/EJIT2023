#include <stdio.h>

int main(void) {
	
	int iTate = 0;
	int iYoko = 0;

	printf("縦と横の数を1～9の値を入力してください\n");
	printf("カンマ区切りで2つの値を入力してください:");
	scanf("%d,%d",&iTate,&iYoko);

	printf("縦: %d  横: %d の四角形を表示します。\n",iTate,iYoko);

	for (int i = 0; i < iTate; i++) {
		for (int j = 0; j < iYoko; j++) {
			printf("*");
		}
		printf("\n");
	}

	return 0;

}
