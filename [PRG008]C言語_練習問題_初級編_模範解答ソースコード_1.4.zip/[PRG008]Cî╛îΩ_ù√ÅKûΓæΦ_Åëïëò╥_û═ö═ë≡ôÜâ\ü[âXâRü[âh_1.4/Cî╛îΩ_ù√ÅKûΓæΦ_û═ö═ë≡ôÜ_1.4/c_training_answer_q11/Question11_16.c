#include <stdio.h>

void changeReverse(char *cmoji){
	if('A'<= *cmoji && *cmoji<= 'Z'){
		*cmoji=*cmoji+('a'-'A');
	}else if('a'<= *cmoji && *cmoji<= 'z'){
		*cmoji=*cmoji-('a'-'A');
	}
}


int main(int args,char **argv){

	char *strargs;
	strargs= argv[1];

	printf("コマンドライン引数の値を扱います\n");
	printf("英大文字→英小文字、英小文字→英大文字に変換します\n");

	printf("\n変換前:%s",strargs);
	
	for(int i=0;i<strlen(strargs);i++){
		changeReverse(&strargs[i]);	
	}

	printf("\n変換後:%s",strargs);


}