#include <stdio.h>

void changeReverse(char *cmoji){
	if('A'<= *cmoji && *cmoji<= 'Z'){
		*cmoji=*cmoji+('a'-'A');
	}else if('a'<= *cmoji && *cmoji<= 'z'){
		*cmoji=*cmoji-('a'-'A');
	}
}

int main(void)
{
	char strInput[256];
	
	printf("入力文字列のアルファベットを大文字→小文字、小文字→大文字に変換します\n");
	printf("英字文字列を入力してください\n");
	scanf("%s",strInput);
	
	for(int i=0;i<strlen(strInput);i++){
		changeReverse(&strInput[i]);	
	}

	printf("%s",strInput);
}