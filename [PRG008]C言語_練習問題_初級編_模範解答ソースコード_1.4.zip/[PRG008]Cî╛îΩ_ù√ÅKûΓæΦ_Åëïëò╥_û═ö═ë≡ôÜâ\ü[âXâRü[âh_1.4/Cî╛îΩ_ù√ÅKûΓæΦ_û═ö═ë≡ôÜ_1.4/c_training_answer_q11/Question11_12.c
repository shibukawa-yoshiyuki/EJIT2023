#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	double dHeight = 0.0;
	double dWeight = 0.0;
	double dBmi = 0.0;
	double dBestWeight = 0.0;
	
	printf("身長(cm)を入力してください。：");
	scanf("%lf",&dHeight);
	dHeight = dHeight/100.0; //cmをメートルに換算

	printf("体重(kg)を入力してください。：");
	scanf("%lf",&dWeight);
	
	dBmi = dWeight/(dHeight*dHeight);
	dBestWeight =(dHeight*dHeight)*22;
	
	printf("身長：%.1fcm 体重: %.1fkg\n",dHeight*100.0,dWeight);
	printf("BMI:%.1f\n", dBmi);
	printf("適正体重:%.1fkg\n",dBestWeight);

	return 0 ; 
}