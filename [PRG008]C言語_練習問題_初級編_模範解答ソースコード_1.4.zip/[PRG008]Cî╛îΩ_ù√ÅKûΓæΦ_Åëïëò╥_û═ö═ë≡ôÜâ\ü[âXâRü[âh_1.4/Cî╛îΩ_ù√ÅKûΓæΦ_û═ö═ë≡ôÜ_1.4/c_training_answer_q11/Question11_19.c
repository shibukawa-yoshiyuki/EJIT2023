#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char **argv) {

	double dHeight = 0.0;
	double dWeight = 0.0;
	double dBmi = 0.0;
	double dBestWeight = 0.0;

	if(argc==3){
		//コマンドライン引数が3つの場合、身長と体重を受け取る
		dHeight = atof( argv[1] )/100.0;
		dWeight = atof( argv[2] );
	}else if(argc==2){
		//コマンドライン引数が2つの場合、体重の入力を促す
		dHeight = atof( argv[1] )/100.0;
		printf("体重(kg)を入力してください。：");
		scanf("%lf",&dWeight);
	}else{
		//コマンドライン引数が2つ、３つ以外の場合、身長と体重の入力を促す
		printf("身長(cm)を入力してください。：");
		scanf("%lf",&dHeight);
		dHeight = dHeight/100.0; //cmをメートルに換算

		printf("体重(kg)を入力してください。：");
		scanf("%lf",&dWeight);
	}
	
	dBmi = dWeight/(dHeight*dHeight);
	dBestWeight =(dHeight*dHeight)*22;
	
	printf("身長：%.1fcm 体重: %.1fkg\n",dHeight*100.0,dWeight);
	printf("BMI:%.1f\n", dBmi);
	printf("適正体重:%.1fkg\n",dBestWeight);

	return 0 ; 
}