#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

int main(void)
{
	char str[256] = "HelloWorld";
	char resultstr1[256];
	sprintf(resultstr1,"文字列%sの長さ%d\n", str,strlen(str));

	char resultstr2[256];
	sprintf(resultstr2,"%s%c", str,'!');
	
	char resultstr3[256];
	sprintf(resultstr3,"---文字を追加---\n文字列%sの長さ%d\n", resultstr2,strlen(resultstr2));

	printf("%s%s", resultstr1,resultstr3);
	return 0;
}
