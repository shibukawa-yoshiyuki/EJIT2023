#include <stdio.h>

const int MAX_SIZE=20;
const int END_NUM=-1;

//バブルソート
void originalSort(int array[],int arraysize){
	for(int i = 0;i < arraysize - 1;i++){
		for(int j = 0;j < arraysize - 1 - i;j++){
			int tmp=0;
			if(array[j] > array[j + 1]){
				tmp=array[j];
				array[j] = array[j+1];
				array[j+1]=tmp;
			}
		}
	}
}

void showArray(int array[],int arraysize){
	for(int i = 0;i < arraysize;i++){
		printf(" %d ",array[i]);
	}
}

int main(void) {

	int array[20];
	int cnt=0;

	printf("---正の整数値を並べ替えます---\n");
	printf("正の整数値を入力してください\n");
	printf("-1を入力する、もしくは20個に到達すると入力受付を終了します\n");
	while(cnt < MAX_SIZE){
		printf("%d 番目の数:",cnt + 1);
		scanf("%d",&array[cnt]);
		if(array[cnt]==END_NUM){
			break;
		}else{
			cnt++;
		}
	} 
	
	printf("並べ替え前の状態：\n");
	showArray(array,cnt);

	originalSort(array,cnt);

	printf("\n並べ替え後の状態：\n");
	showArray(array,cnt);

	return 0;
}
