#include <stdio.h>
#include <stdbool.h>
const double PI = 3.14;

//半径から円周を計算する
void calcCircleLength(double dRadius,double *circleLength) {
	*circleLength = 2.0*PI*dRadius;
	return;
}
//半径から円の面積を計算する
void calcCircleArea(double dRadius,double *circleArea) {
	*circleArea = dRadius * dRadius * PI;
	return;
}
//円周表示の文字列を作る
void makeStringLength(char str[256],double *circleLength){
	sprintf(str,"\n---円周を表示します---\n円周 : %.2f\n", *circleLength);
}
//円の面積表示の文字列を作る
void makeStringArea(char str[256],double *circleArea){
	sprintf(str,"\n---円の面積を表示します---\n円の面積：%.2f\n",*circleArea);
}
//円周、円の面積表示の文字列を作る
void makeStringLengthArea(char str[256],double *circleLength,double *circleArea){
	char strLength[256];
	char strArea[256];
	makeStringLength(strLength,circleLength);
	makeStringArea(strArea,circleArea);
	sprintf(str,"%s%s",strLength,strArea);
}
//英小文字→英大文字に変換
void changeLowertoUpper(char *cmoji){
	if('a'<= *cmoji && *cmoji<= 'z'){
		*cmoji=*cmoji-('a'-'A');
	}
}

int main(void)
{
	double circleLength=0.0;
	double circleArea=0.0;
	double dnum = 0;
	char menu = '0';
	bool outputflg = 0;
	char outputStr[256];
	
	printf("---円周率、円の面積を計算するプログラム---\n");

	printf("半径を小数点第1位までの数値で入力してください\n");
	printf("半径: ");
	scanf("%lf",&dnum);
	
	//代入抑止
	// 連続してscanfを行う場合の回避方法
	//https://ja.wikipedia.org/wiki/Scanf
	scanf("%*c"); 

	while(!outputflg){
		printf("\nメニューの文字を入力してください\n");
		printf("A or a: 円周と円の面積を表示\n");
		printf("B or b: 円周を表示\n");
		printf("C or c: 円の面積を表示\n");
		printf("メニューの文字: \n");
		scanf("%c",&menu);
		changeLowertoUpper(&menu);

		if(menu=='A'){
			calcCircleLength(dnum,&circleLength);
			calcCircleArea(dnum,&circleArea);
			makeStringLengthArea(outputStr,&circleLength,&circleArea);
			outputflg=true;
		}else if(menu=='B'){
			calcCircleLength(dnum,&circleLength);
			makeStringLength(outputStr,&circleLength);
			outputflg=true;
		}else if(menu=='C'){
			calcCircleArea(dnum,&circleArea);
			makeStringArea(outputStr,&circleArea);
			outputflg=true;
		}else{
			printf("\nもう一度入力してください\n");
			scanf("%*c"); //代入抑止
		}
	}
	printf("%s",outputStr);
	return 0;
}