#include <stdio.h>

int main()
{
	char str1[256] = "ありがとう";
	char str2[256] = "ございました";

	printf("----連結前----\n");

	printf("連結先の文字列(str1): %s\n", str1);
	printf("連結する文字列(str2): %s\n", str2);

	printf("\n文字列の連結を行います\n\n");
	strcat(str1, str2);

	printf("----連結後----\n");
	printf("連結後の文字列(str1): %s\n", str1);
	printf("連結する文字列(str2): %s\n", str2);

	return 0;
}
