#include <stdio.h>

int main()
{
	char str1[256] = "コピー未完了";
	char str2[256] = "コピー完了";

	printf("----コピー前----\n");
	printf("コピー元 : %s\n", str2);
	printf("コピー先 : %s\n", str1);

	printf("\n内容をコピーします\n\n");

	strcpy(str1, str2);
	printf("----コピー後----\n");
	printf("コピー元 : %s\n", str2);
	printf("コピー先 : %s\n", str1);

	return 0;
}

