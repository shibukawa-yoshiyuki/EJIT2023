#include <stdio.h>
#include <stdbool.h>

const int TAXRATE_8 = 8;
const int TAXRATE_10 = 10;
typedef struct {
	char name[256];
	int price;
	int tax8Price;
	int tax10Price;
	int priceTax8in;
	int priceTax10in;
}tagLunchBox;

void initLunchBoxData(tagLunchBox *lunchbox){
	lunchbox->tax8Price = taxCalc(lunchbox->price,TAXRATE_8);
	lunchbox->priceTax8in =lunchbox->price+lunchbox->tax8Price;
	lunchbox->tax10Price = taxCalc(lunchbox->price,TAXRATE_10);
	lunchbox->priceTax10in =lunchbox->price+lunchbox->tax10Price;
}

int taxCalc(int lunchBoxPrice,const int taxRate) {
	lunchBoxPrice *= (double)(taxRate/100.0);
	return lunchBoxPrice;
}

void showPrice(tagLunchBox *lunchbox, int iEatinFlg) {

	printf("---- %s の価格 ----\n", lunchbox->name);
	
	if(iEatinFlg==0){
		//持ち帰り
		printf("持ち帰りの税率: %d%%\n", TAXRATE_8);
		printf("税込み(%d%%)価格\t: %d円\n", TAXRATE_8,lunchbox->priceTax8in);
		printf("消費税額(%d%%)\t: %d円\n", TAXRATE_8,lunchbox->tax8Price);
	}else{
		//イートイン
		printf("イートインの税率: %d%%\n", TAXRATE_10);
		printf("税込み(%d%%)価格\t: %d円\n", TAXRATE_10,lunchbox->priceTax10in);
		printf("消費税額(%d%%)\t: %d円\n", TAXRATE_10,lunchbox->tax10Price);
	}
}

int main(int argc, const char **argv) {

	if(argc!=4){
		//コマンドライン引数の長さが短いもしくは長すぎる場合、
		//使い方を表示
		printf("以下の形式でプログラムを動かしてください\n");
		printf("Usage : Question11_18 値1 値2 値3\n");
		printf("値1: お弁当名を入力\n");
		printf("値2: 価格を半角数字で入力\n");
		printf("値3: out もしくは inと入力 :out-持ち帰り、in-イートイン\n");
	}else{
		tagLunchBox lunchbox;

		strcpy(lunchbox.name,argv[1]);
		lunchbox.price = atoi(argv[2]);

		// 構造体の初期化処理
		initLunchBoxData(&lunchbox);
		
		//printf("持ち帰りの場合:0、イートインの場合:1を入力してください。\n");
		int iEatinFlg = 0;
		if(!strcmp(argv[3],"out")){
			iEatinFlg = 0;
		}else if(!strcmp(argv[3],"in")){
			iEatinFlg = 1;
		}else{
			printf("持ち帰りかイートインかが読み取れませんでした。\n");
			printf("持ち帰りの場合:0、イートインの場合:1を入力してください。\n");
			scanf("%d",&iEatinFlg);
		}
		showPrice(&lunchbox,iEatinFlg);
	}
	return 0;
}


