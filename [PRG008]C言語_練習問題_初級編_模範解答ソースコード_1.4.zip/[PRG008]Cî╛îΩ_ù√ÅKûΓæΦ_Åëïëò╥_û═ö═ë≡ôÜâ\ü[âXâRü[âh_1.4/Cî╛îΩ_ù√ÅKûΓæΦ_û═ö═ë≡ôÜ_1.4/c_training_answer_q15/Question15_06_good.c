#include <stdio.h>
int main(void)
{
	char a,b,c;
	a=0;
	b=127;
	c=3;
	
	a = (b << 1) + c;
	printf("a=%d",a);

	return 0;
}
