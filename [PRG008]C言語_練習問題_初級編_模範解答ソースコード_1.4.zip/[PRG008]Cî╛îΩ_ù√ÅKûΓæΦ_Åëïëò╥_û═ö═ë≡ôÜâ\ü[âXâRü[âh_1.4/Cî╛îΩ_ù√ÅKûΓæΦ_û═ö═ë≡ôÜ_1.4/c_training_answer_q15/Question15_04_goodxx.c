#include <stdio.h>

int main(void)
{
	int a[5]={1,2,3,4,5};
	int *top_p=a;
	int *p;

	char c[5]="abc";
	char *pc=c;

	p = top_p;
	if (p != NULL) {
		printf("%d\n",*p);
	}
	int i=0;
	c[0] = *pc++;
	while (c != '\0') {
		printf("%c\n",*pc);
		c[i] = *pc++;
		i++;
	}
}