#include <stdio.h>

int main(void)
{
	double d=0;
	int i=22;
	
	d = (double)5 / (double)9*i+32;  // 整数型での除算

	printf("d=%f\n",d);

	return 0;
}