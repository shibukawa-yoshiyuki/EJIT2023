#include <stdio.h>

int main(void) {
	int a[2]={10,20};
	int *pa=a;
	int i=0;
	int c=pa[i];
	int d=pa[i+1];

	int b[2]={10,20};
	int *pb =b;
	int e=pb[i];
	int f=pb[i+1];

	if(c==e){
		printf("処理終了後c:%dとe:%dは同じ値です\n",c,e);
	}
	if(d==f){
		printf("処理終了後d:%dとf:%dは同じ値です\n",d,f);
	}

	return 0;
}