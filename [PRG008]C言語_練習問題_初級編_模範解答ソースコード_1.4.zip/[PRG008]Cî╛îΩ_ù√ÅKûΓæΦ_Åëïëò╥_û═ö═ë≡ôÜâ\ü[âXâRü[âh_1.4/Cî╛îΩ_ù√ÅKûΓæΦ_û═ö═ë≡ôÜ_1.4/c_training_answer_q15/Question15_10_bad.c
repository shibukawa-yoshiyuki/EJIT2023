#include <stdio.h>

int main(void) {
	int a[2]={10,20};
	int *pa=a;
//	printf(" 6行目:pa=%p\n",pa);
	int c=*pa++;
//	printf(" 8行目:pa=%p,c=%d\n",pa,c);
	int d=*pa++;
//	printf("10行目:pa=%p,c=%d,d=%d\n",pa,c,d);

	int b[2]={10,20};
	int *pb =b;
//	printf("14行目:pb=%p\n",pb);
	int e=(*pb)++;
//	printf("16行目:pb=%p,e=%d\n",pb,e);
	int f=(*pb)++;
//	printf("18行目:pb=%p,e=%d,f=%d\n",pb,e,f);
	
	if(c==e){
		printf("処理終了後c:%dとe:%dは同じ値です\n",c,e);
	}else{
		printf("処理終了後c:%dとe:%dは違う値です\n",c,e);
	}
	if(d==f){
		printf("処理終了後d:%dとf:%dは同じ値です\n",d,f);
	}else{
		printf("処理終了後d:%dとf:%dは違う値です\n",d,f);
	}
	
	return 0;
}