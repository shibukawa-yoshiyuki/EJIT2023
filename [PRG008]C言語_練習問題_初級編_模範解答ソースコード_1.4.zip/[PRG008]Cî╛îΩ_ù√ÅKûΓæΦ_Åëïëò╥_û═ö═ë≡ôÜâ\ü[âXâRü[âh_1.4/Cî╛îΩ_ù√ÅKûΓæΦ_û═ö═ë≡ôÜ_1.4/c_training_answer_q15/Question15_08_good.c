#include <stdio.h>
#define FALSE 0

int func1(){
	return 2;
}
  	// func1は0と1以外を返す可能性がある
void func2() {
	if (func1() != FALSE) {
		printf("func1の結果はTRUE\n");
	}else{
		printf("func1の結果はFALSE\n");
	}
}

int main(void)
{
	func2();

	return 0;
}
