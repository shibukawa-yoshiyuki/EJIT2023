#include <stdio.h>

int main(void)
{
	int x,y,ans;
	x=7;
	y=0;
	ans=-1;

    ans = x/y;
	printf("ansの値を表示\n");
	printf("ans=%d",ans);

	return 0;
}
