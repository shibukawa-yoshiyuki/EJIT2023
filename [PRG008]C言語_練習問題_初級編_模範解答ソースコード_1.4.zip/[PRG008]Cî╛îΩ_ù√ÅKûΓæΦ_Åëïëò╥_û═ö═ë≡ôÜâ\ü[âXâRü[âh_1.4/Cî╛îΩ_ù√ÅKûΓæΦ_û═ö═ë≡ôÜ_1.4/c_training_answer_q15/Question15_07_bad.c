#include <stdio.h>

int func1(){
	printf("func1が呼ばれました");
	return 2;
}

int main(void)
{
	int x;
	x=2;
	if ((x != 0) || (func1()==0)) {
		printf("if文はTRUE");
	} else{
		printf("if文はFALSE");
	}

	return 0;
}
