#include <stdio.h>

int main(void)
{
	int ival=301;
	char cval=ival;
	unsigned short uival=65535;
	ival=uival;
	
	printf("cval=%d\n",cval);
	printf("uival=%d\n",uival);
	printf("ival=%d\n",ival);

	return 0;
}