#include <stdio.h>

int main(void)
{

	int a[5]={1,2,3,4,5};
	int *top_p=a;
	int *p;

	char c[5]="abc";
	char *pc;
	if (p = top_p) {
		printf("%d\n",*p);
	}

	int i=0;
	while (c[i] = *pc++) {
		printf("%c\n",*pc);
		c[i] = *pc++;
		i++;
	}


	return 0;
}