#include <stdio.h>

int main(void)
{
	double d;
	int i=0;
	for(d=0.0;d!=0.1;d+=0.01){
		printf("%d回目\n",i);
		i++;
	}
	
	return 0;
}
