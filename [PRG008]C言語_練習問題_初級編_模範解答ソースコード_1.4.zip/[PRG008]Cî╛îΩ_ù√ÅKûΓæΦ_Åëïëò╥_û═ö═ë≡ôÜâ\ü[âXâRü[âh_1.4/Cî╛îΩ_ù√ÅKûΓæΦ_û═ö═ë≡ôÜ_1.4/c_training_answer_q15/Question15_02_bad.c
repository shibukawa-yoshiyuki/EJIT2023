#include <stdio.h>

int main(void)
{
	double d=0;
	int i=22;

	d = 5 / 9*i+32;  

	printf("d=%f\n",d);

	return 0;
}