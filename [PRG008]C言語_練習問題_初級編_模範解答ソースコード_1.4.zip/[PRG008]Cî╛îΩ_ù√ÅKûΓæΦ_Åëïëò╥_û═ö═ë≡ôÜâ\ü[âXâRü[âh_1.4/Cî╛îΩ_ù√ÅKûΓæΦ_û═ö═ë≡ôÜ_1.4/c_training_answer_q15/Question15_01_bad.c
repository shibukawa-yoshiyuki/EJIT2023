#include <stdio.h>

int main(void)
{
	const int a = 000;
	const int b = 010;
	const int c = 100;
	
    int d = 5;
    
    printf("a*d=%d\n",a*5);
    printf("b*d=%d\n",b*5);
    printf("c*d=%d\n",c*5);

    return 0;
}