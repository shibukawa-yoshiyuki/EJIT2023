#include <stdio.h>

int main(void)
{
	int ival=301;
	// char型は1バイトのため、256までの数値しか格納できない
	// 256以下になるように明示的にキャストし値を変換する、
	char cval=(char)ival;

	unsigned short uival=65535;
	ival=(short)uival;

	printf("cval=%d\n",cval);
	printf("uival=%d\n",uival);
	printf("ival=%d\n",ival);

	return 0;
}