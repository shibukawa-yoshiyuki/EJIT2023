#include <stdio.h>

int main(void)
{

	unsigned char uc = 0x0f;
	if((unsigned char)(~uc) >= 0x0f){
		printf("0x0f以上\n");
	}else{
		printf("0x0f未満\n");
	}

	return 0;
}

