#include <stdio.h>

int main(void) {

	printf("15＋6は%dです\n",15 + 6);
	printf("15－6は%dです\n",15 - 6);
	printf("15×6は%dです\n",15 * 6);
	printf("15÷6は%dです\n",15 / 6);
	printf("15÷6の余りは%dです\n",15 % 6);
	
	return 0;
}
