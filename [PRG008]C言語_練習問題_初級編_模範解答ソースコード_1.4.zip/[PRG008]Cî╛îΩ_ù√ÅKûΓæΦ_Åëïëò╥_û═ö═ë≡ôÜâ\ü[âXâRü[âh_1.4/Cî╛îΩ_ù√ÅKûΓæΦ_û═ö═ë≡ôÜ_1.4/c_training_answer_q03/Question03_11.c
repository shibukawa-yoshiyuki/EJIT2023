#include <stdio.h>

int main(void)
{
	int iTopside = 4;
	int iBottomside = 9;
	int iHeight = 5;

	double dArea = (((double)iTopside + (double)iBottomside) * (double)iHeight) / 2.0;

	printf("台形の面積 (%dcm+%dcm)×%dcm÷2=%.1f\n",iTopside,iBottomside,iHeight,dArea);

	return 0;
}