#include <stdio.h>

int main(void)
{
	int inum1, inum2;
	inum1 = 25;
	inum2 = 5;
	printf("たし算の結果は、%d\n", inum1 + inum2);
	printf("ひき算の結果は、%d\n", inum1 - inum2);
	printf("かけ算の結果は、%d\n", inum1 * inum2);
	printf("割り算の結果は、%d\n", inum1 / inum2);
	return 0;
}