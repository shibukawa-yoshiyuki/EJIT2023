#include <stdio.h>

int main(void)
{
	const double PI = 3.14;
	double dLen = 18.84;

	double dRadius = (dLen/PI)/2;
	double dArea = dRadius * dRadius * PI;

	printf("円の半径：%d\n", (int)dRadius);
	printf("円の面積：%.2f\n", dArea);
	return 0;
}