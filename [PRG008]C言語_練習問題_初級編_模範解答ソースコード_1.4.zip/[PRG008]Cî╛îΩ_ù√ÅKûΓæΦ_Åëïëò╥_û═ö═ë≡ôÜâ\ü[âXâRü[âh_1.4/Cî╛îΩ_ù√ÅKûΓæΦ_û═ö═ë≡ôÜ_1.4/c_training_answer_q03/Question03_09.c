#include <stdio.h>

int main(void) {

	int inum = 10;
	double dnum;

	dnum = inum;

	printf("inumをdnumに代入すると%.1fです。\n", dnum);

	return 0;
}