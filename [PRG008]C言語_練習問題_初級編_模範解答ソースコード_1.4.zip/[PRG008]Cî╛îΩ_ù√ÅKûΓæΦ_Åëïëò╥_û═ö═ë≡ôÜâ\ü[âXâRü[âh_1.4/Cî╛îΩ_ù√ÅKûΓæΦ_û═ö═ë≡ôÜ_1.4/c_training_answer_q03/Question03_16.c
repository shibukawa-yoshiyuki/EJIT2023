#include <stdio.h>
#include <stdlib.h>

typedef char String[1024];
int main(void)
{
	double dHeight= 0.0;
	int iWeight = 0;
	double dBmi = 0.0;
	double dBestWeight = 0.0;
	String strInput = "";
	
	printf("身長(cm)を整数値で入力してください。：");
	scanf("%s",strInput);
	dHeight = (double)atoi(strInput)/100.0; //cmをメートルに換算

	printf("体重(kg)を整数値で入力してください。：");
	scanf("%s",strInput);
	iWeight = atoi(strInput); 
	
	dBmi = (double)iWeight/(dHeight*dHeight);
	dBestWeight =(dHeight*dHeight)*22;
	
	printf("身長：%dcm 体重: %dkg\n",(int)(dHeight*100.0),iWeight);
	printf("BMI:%.1f\n", dBmi);
	printf("適正体重:%.1fkg\n",dBestWeight);

	return 0 ; 
}
