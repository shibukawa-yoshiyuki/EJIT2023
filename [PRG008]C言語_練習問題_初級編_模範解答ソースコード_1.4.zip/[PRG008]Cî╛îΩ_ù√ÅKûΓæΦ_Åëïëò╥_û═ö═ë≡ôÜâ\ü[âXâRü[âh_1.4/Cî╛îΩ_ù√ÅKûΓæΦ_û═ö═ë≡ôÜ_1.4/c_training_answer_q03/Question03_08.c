#include <stdio.h>

int main(void) {

	double dnum = 10.5;
	int inum;

	inum = (int)dnum;

	printf("dnumをinumに代入すると%dです。\n", inum);

	return 0;
}