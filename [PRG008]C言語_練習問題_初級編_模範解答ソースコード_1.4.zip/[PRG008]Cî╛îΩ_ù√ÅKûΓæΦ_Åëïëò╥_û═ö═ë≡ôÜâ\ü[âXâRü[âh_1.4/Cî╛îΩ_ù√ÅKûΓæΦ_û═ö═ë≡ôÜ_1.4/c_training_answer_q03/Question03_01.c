#include <stdio.h>

int main(void) {

	printf("少年老い易く\t学成り難し\n一寸の光陰軽んずべからず\n");

	return 0;
}
