#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	srand(time(NULL));

	int iNumber;
	iNumber = rand() % 6 + 1;

	printf("サイコロを振ります。\n");
	printf("サイコロの目は%dでした。", iNumber);

	return 0 ; 
}