#include <stdio.h>

int main(void) {

	int inum = 10;

	printf("inumの値は%dです\n", inum);
	printf("inumに1を足すと%dです\n\n", ++inum);
	printf("表示後にinumの値(%d)から1を引きます\n\n", inum--);
	printf("inumの値は%dです\n", inum);
	printf("inumから1を引くと%dです\n", --inum);

	return 0;
}
