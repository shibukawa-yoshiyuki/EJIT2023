#include <stdio.h>
#include <stdlib.h>

typedef char String[1024];
int main(void)
{
	double dCe= 0.0;
	double dFa= 0.0;
	String strInput = "";
	
	printf("温度(摂氏°C)を入力してください。：");
	scanf("%s",strInput);
	dCe = (double)atoi(strInput); 
	
	dFa = (9.0/5.0)*dCe+32.0;
	
	printf("摂氏温度：%.1f°C 華氏温度: %.1f°F\n",dCe,dFa);

	return 0 ; 
}
