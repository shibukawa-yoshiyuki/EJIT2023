#include <stdio.h>

int main(void) {

	int inum = 10;
	printf("%dに", inum);
	inum += 5;
	printf("5を加えた値は%dです\n", inum);
	inum -= 3;
	printf("加算結果から3を引いた値は%dです\n", inum);
	return 0;
}
