#include <stdio.h>

int main(void)
{
	char cMoji = 'A';

	printf("%c%c%c\n",cMoji,cMoji+1,cMoji+2);

	return 0;
}