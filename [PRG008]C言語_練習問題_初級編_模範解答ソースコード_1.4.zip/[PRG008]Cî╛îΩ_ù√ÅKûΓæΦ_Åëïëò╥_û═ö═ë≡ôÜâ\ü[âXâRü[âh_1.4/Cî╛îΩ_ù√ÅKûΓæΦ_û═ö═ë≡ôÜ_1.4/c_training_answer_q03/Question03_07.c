#include <stdio.h>

int main(void)
{
	const double PI = 3.14;
	double dRadius = 5.0;
	double dLen = 2 * dRadius * PI;
	double dArea = dRadius * dRadius * PI;

	printf("円周の長さ：%.1f\n",dLen);
	printf("円の面積：%.1f\n", dArea);
	return 0;
}