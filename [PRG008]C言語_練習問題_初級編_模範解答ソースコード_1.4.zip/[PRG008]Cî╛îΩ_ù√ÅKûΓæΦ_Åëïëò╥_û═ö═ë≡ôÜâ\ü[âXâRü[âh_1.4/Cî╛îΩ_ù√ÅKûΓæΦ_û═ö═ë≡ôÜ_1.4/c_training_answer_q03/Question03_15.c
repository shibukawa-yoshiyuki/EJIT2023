#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef char String[1024];
int main(void)
{
	srand(time(NULL));

	int iRandnum;
	const double TAX = 0.10;
	double dDiscRate = 0.0;
	String strInput = "";
	int iPrice=0;
	int iDiscPrice = 0;
	double dPriceTAX =0.0;
	
	printf("商品価格を入力してください。：");
	scanf("%s",strInput);
	iPrice = atoi(strInput);

	iRandnum = rand() % 44+5;
	dDiscRate = (double)iRandnum/100.0;
	iDiscPrice =(int)(iPrice-(iPrice*dDiscRate));
	dPriceTAX = (double)iDiscPrice * TAX;

	printf("\n商品の価格は、\\%dです。\n",iPrice);
	printf("本日、あなたの値引き率は%d%%です。\n", iRandnum);
	printf("\\%dの商品が、税抜き\\%dで購入できます。\n", iPrice,iDiscPrice);
	printf("消費税額(1円以下切り捨て)は、\\%dです。\n", (int)dPriceTAX);
	printf("値引き後の商品価格(税込み)は、\\%dです。\n", (int)dPriceTAX + iDiscPrice);

	return 0 ; 
}
