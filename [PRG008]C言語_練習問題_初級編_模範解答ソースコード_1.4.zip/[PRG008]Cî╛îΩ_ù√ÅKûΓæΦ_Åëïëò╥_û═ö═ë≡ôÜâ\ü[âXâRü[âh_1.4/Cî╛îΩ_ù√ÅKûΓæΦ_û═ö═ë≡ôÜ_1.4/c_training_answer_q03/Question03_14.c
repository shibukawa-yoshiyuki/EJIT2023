#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	srand(time(NULL));

	int iRandnum;
	const double TAX = 0.10;
	double dDiscRate = 0.0;
	int iPrice = 0;
	double dPriceTAX =0.0;
	
	iRandnum = rand() % 44+5;
	dDiscRate = (double)iRandnum/100.0;
	iPrice =(int)(1000-(1000*dDiscRate));
	dPriceTAX = (double)iPrice * TAX;

	printf("本日の値引き率が決定しました！\n");
	printf("あなたの値引き率は%d%%です。\n", iRandnum);
	printf("1000円の商品の場合、税抜き\\%dで購入できます。\n", iPrice);
	printf("消費税額(1円以下切り捨て)は、\\%dです。\n", (int)dPriceTAX);

	return 0 ; 
}
