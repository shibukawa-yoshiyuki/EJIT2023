﻿#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void writeLine(char* fileName, char* name,int year,int month,int day,char* job) {
	FILE* fp;
	printf("----------ファイルへの書き込みを行います----------\n");
	printf("ファイル名:%s\n", fileName);

	// 書き込み専用でオープン
	if ((fp = fopen(fileName, "w")) == NULL) {
		printf("ファイルがオープンできませんでした\n");
		exit(1);
	}
	//書き込み
	fprintf(fp,"名前は「%s」\n",name);
	fprintf(fp, "生年月日は「%d年%d月%d日」\n",year,month,day);
	fprintf(fp, "職業は「%s」\n",job);

	fclose(fp);
	printf("----------ファイルへの書き込みが完了しました------\n");
}

void readLine(char* fileName) {
	FILE* fp;
	char readstr[256];
	// 読み取り専用でオープン
	if ((fp = fopen(fileName, "r")) == NULL) {
		printf("ファイルがオープンできませんでした\n");
		exit(1);
	}
	printf("----------ファイルの内容を表示します--------------\n");
	printf("ファイル名:%s\n", fileName);
	while (fgets(readstr, 256, fp) != NULL) {
		printf("%s", readstr);    // 標準出力(画面)に表示
	}
	fclose(fp);
}

//入力チェック
bool inputCheck(int year, int month, int day) {
	if (0>=year||(0>=month||month>=13)||(0>=day||day>=32)) {
		printf("不正な値が入力されました。\nシステムを終了します。");
		return false;
	}
	return true;
}
int main(void)
{
	char fileName[256] = "memo.txt";
	char name[256] = "demo";
	int year;
	int month;
	int day;
	char job[256] = "sample";

	printf("ファイル名を[英数字8文字以内].txtの形式で入力してください\n");
	scanf("%s", fileName);

	printf("名前を入力してください：");
	scanf("%s",name);
	printf("生年月日はスペース区切りで入力してください：");
	scanf("%d %d %d",&year,&month,&day);
	printf("職業を入力してください。");
	scanf("%s",job);

	bool checkFlag = false;
	checkFlag=inputCheck(year,month,day);
	if (checkFlag) {
		writeLine(fileName,name,year, month, day,job);
		readLine(fileName);
	}
	return 0;
}

