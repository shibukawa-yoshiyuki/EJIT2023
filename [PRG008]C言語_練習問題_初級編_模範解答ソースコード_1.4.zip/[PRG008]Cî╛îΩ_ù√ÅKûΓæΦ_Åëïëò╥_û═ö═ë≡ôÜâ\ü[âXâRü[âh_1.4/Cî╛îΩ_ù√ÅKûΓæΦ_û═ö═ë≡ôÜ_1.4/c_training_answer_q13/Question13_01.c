#include <stdio.h>
#include <stdlib.h>

int main(void){
	FILE *fp;
	int moji;
	char filename[]="memo.txt";
	char amode[]="w";

	if((fp=fopen(filename, amode)) == NULL){
    	printf("出力ファイルをオープンできません。\n");
		exit(1);
  	}

	printf("文字を入力してください。\n");
	printf("Ctl+Z を押すと終了します。\n");
	
	while ((moji=getchar()) != EOF){
		fputc(moji, fp);
	}

  	fclose(fp);

	return 0;
}