#include <stdio.h>
#include <stdlib.h>

void writeLine(char *filename,char **ppmem,int *cnt){
	FILE* fp;
	char writestr[256];

	// 書き込み専用でオープン
	if((fp = fopen(filename, "w")) == NULL) {
		printf("ファイルがオープンできませんでした\n");
		exit(1);
	}

	printf("----------ファイルへの書き込みを行います----------\n");
	printf("ファイル名:%s\n",filename);

	for (int i = 0; i < *cnt; i++){
		sprintf(writestr,"%s\n",ppmem[i]);
		fputs(writestr, fp);
	}
	fclose(fp);
	printf("----------ファイルへの書き込みが完了しました------\n");
	
	return;
}

void readLine(char *filename) {
	FILE* fp;
	char readstr[256]; 

  // 読み取り専用でオープン
	if ((fp = fopen(filename, "r")) == NULL) {
		printf("ファイルがオープンできませんでした\n");
		exit(1);
	}
	printf("----------ファイルの内容を表示します--------------\n");
	printf("ファイル名:%s\n",filename);
	while (fgets(readstr, 256, fp) != NULL) {
    	printf("%s", readstr);    // 標準出力(画面)に表示
  	}

	fclose(fp);
	return;
}

void memfree(char **ppmem,int *cnt){
	for (int i = 0; i < *cnt; i++){
		 free(ppmem[i]);		
	}
	free(ppmem); 
}


int main(void)
{
	char filename[256]="memo.txt";
	char str[256]; 
	char **ppmem;// char型ポインタへのポインタ
	int cnt;

	
	printf("ファイル名を[英数字8文字以内].txtの形式で入力してください\n");
	scanf("%s", filename);

	// 入力する文字列の数を入力
	printf("入力する行数を入れてください: ");
	scanf("%d", &cnt);

	// 文字列の数分のchar型ポインタを格納するためのメモリを確保
	ppmem = (char **)malloc(sizeof(char *) * cnt);
	if (ppmem==NULL) {
		printf("メモリ確保に失敗しました\n");
		exit(1);
	}

	memset(ppmem,'\0',sizeof(char *) * cnt);

	for (int i = 0; i < cnt; i++) {
		printf("%d行目 #: ", i+1);
		scanf("%s", str); 
		ppmem[i]=(char *)malloc(sizeof(char)*(strlen(str)+1));
		if (ppmem[i]==NULL) {
			printf("メモリ確保に失敗しました\n");
			memfree(ppmem,&cnt);
			exit(1);
		}
		strcpy(ppmem[i], str); 
	}

	writeLine(filename,ppmem,&cnt);

	readLine(filename);

	memfree(ppmem,&cnt);

	return 0;
}

