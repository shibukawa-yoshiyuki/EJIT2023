#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void input(char *text,int *len) {
	printf("-----------input----------\n");

	printf("input:ファイルに書き込みする文字を入力してください\n");
	printf("input:改行を入力すると、ファイルへの書き込みを開始します\n");
	scanf("%s", text);
	*len = strlen(text);	
	return;
}

void write(char *filename,char *text, int len){
	FILE *fp;
	printf("-----------write----------\n");

	if ((fp = fopen(filename, "w")) == NULL) {
		printf("write:ファイルのオープンに失敗しました\n");
		exit(1);
	}
	printf("write:ファイルへの書き込みを開始します\n");
	printf("write:書き込み文字列:%s\n",text);

	for (int i = 0; i < len; i++) {
		fputc(text[i], fp);         
	}

	fclose(fp);
	printf("write:ファイルへの書き込みが完了しました\n");
	return;
}

void read(char *filename){
	FILE *fp;
	int ch = 0;

	printf("-----------read----------\n");

	if ((fp = fopen(filename, "r")) == NULL) {
		printf("read:ファイルのオープンに失敗しました\n");
		exit(1);
	}

	printf("read:ファイルからの読み込み内容を表示します\n");
	while ((ch = fgetc(fp)) != EOF) {
		putchar((char)ch);
	}

	fclose(fp);
	return;
}

int main(void) {
	char text[256] = { 0 };
	char filename[256]="memo.txt";
	int len =0;

	printf("main:ファイル名を[英数字8文字以内].txtの形式で入力してください\n");
	scanf("%s", filename);

	input(text, &len);
	write(filename,text, len);
	read(filename);

	return 0;
}
