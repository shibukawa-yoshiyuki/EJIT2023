#include <stdio.h>
#include <stdlib.h>

void writeLine(char *filename,char *str){
	FILE* fp;
	printf("----------ファイルへの書き込みを行います----------\n");
	printf("ファイル名:%s\n",filename);

	// 書き込み専用でオープン
	if((fp = fopen(filename, "w")) == NULL) {
		printf("ファイルがオープンできませんでした\n");
		exit(1);
	}
	
	fputs(str, fp);

	fclose(fp);
	printf("----------ファイルへの書き込みが完了しました------\n");
}

void readLine(char *filename) {
	FILE* fp;
	char readstr[256]; 
	  // 読み取り専用でオープン
	if ((fp = fopen(filename, "r")) == NULL) {
		printf("ファイルがオープンできませんでした\n");
		exit(1);
	}
	printf("----------ファイルの内容を表示します--------------\n");
	printf("ファイル名:%s\n",filename);
	while (fgets(readstr, 256, fp) != NULL) {
    	printf("%s", readstr);    // 標準出力(画面)に表示
  	}
	fclose(fp);
}

int main(void)
{
	char filename[256]="memo.txt";
	char str[256]="\0"; 
	
	printf("ファイル名を[英数字8文字以内].txtの形式で入力してください\n");
	scanf("%s", filename);

	printf("書き込み文字列を3行で入力してください。\n");
	for(int i=0;i<3;i++){
		char inputstr[64];
		scanf("%s", inputstr);
		strcat(str,inputstr);
		sprintf(str,"%s\n",str);
	}
	
	writeLine(filename,str);
	readLine(filename);

  return 0;
}

