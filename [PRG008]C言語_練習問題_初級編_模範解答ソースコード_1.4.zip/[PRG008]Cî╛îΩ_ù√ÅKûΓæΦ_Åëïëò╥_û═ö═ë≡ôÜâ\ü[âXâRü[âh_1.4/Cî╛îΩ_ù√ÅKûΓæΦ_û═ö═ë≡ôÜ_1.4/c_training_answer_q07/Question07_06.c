#include <stdio.h>
typedef char String[1024];

int main(void) {
	
	String strInput="";
	int inum = 0;

	typedef struct{
		char cInitmoji;
		int iEnglish;
		int iMath;
		int iHistory;
		int iScience;
		int iGeography;
		double dAvg;
	}tagTestScore;

	tagTestScore student1={'1',0,0,0,0,0,0};
	tagTestScore student2={'2',0,0,0,0,0,0};
	tagTestScore student3={'3',0,0,0,0,0,0};

	tagTestScore students[]={student1,student2,student3};


	for(int i=0; i< 3; i++){
		printf("\n---%d人目の情報を入力してください---\n",i+1);
		printf("苗字の頭文字をアルファベット1文字で入力してください : ");
		scanf("%s",strInput);
		students[i].cInitmoji = strInput[0];
		printf("英語の点数を入力してください : ");
		scanf("%s",strInput);
		students[i].iEnglish = atoi(strInput);
		printf("\n数学の点数を入力してください : ");
		scanf("%s",strInput);
		students[i].iMath = atoi(strInput);
		printf("\n歴史の点数を入力してください : ");
		scanf("%s",strInput);
		students[i].iHistory = atoi(strInput);
		printf("\n科学の点数を入力してください : ");
		scanf("%s",strInput);
		students[i].iScience = atoi(strInput);
		printf("\n地理の点数を入力してください : ");
		scanf("%s",strInput);
		students[i].iGeography = atoi(strInput);
	}
	
	for(int i=0; i< 3; i++){
		
		int iSum = students[i].iEnglish 
				 + students[i].iMath
				 + students[i].iHistory
				 + students[i].iScience
				 + students[i].iGeography;

		students[i].dAvg = (double)iSum/5;
		
		printf("\n---%cさんのテスト結果---\n", students[i].cInitmoji);
		printf("5科目の合計点 : %d\n", iSum);
		printf("5科目の平均点 : %.1f\n", students[i].dAvg);
	}
	return 0;

}
