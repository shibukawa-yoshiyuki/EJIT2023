#include <stdio.h>
typedef char String[1024];

//科目名と点数の構造体
typedef struct{
	String strKamoku;
	int iScore;
}tagKamokuScore;


int main(void) {
	tagKamokuScore kamokuScore[] 
		= {{"英語", 88},
	 	   {"数学", 63},
	 	   {"歴史", 54},
	 	   {"科学", 76},
	 	   {"地理", 45}};
	 	   
	int cnt = sizeof(kamokuScore)/sizeof(kamokuScore[0]);
	
	printf("並べ替え前の状態：\n");
	for(int i = 0;i < cnt;i++){
		printf("\t科目名:%s 点数:%d\n",kamokuScore[i].strKamoku,kamokuScore[i].iScore);
	}
	
	for(int i = 0;i < cnt - 1;i++){
		for(int j = 0;j < cnt - 1 - i;j++){
			tagKamokuScore tmp;
			if(kamokuScore[j].iScore < kamokuScore[j + 1].iScore){
				tmp=kamokuScore[j];
				kamokuScore[j] = kamokuScore[j+1];
				kamokuScore[j+1]=tmp;
			}
		}
	}
	printf("\n並べ替え後の状態：\n");
	for(int i = 0;i < cnt;i++){
		printf("\t科目名:%s 点数:%d\n",kamokuScore[i].strKamoku,kamokuScore[i].iScore);
	}
}