#include <stdio.h>
//バブルソート
int main(void) {
	int iNumbers[] = { 31,41,59,26,53,58,97,93,23,84 };

	printf("並べ替え前の状態：");
	for(int i = 0;i < 10;i++){
		printf(" %d ",iNumbers[i]);
	}
	
	for(int i = 0;i < 10 - 1;i++){
		for(int j = 0;j < 10 - 1 - i;j++){
			int tmp=0;
			if(iNumbers[j] > iNumbers[j + 1]){
				tmp=iNumbers[j];
				iNumbers[j] = iNumbers[j+1];
				iNumbers[j+1]=tmp;
			}
		}
	}
	printf("\n並べ替え後の状態：");
	for(int i = 0;i < 10;i++){
		printf(" %d ",iNumbers[i]);
	}

	return 0;
}
