#include <stdio.h>

int main(void) {
	int num1[3];
	int num2[3];
	
	num1[0] = 10;
	num1[1] = 20;
	num1[2] = 30;
	num2[0] = 40;
	num2[1] = 50;
	num2[2] = 60;

	printf("1段目の中身は%dです\n", num1[0]);
	printf("2段目の中身は%dです\n", num1[1]);
	printf("3段目の中身は%dです\n", num1[2]);
	printf("4段目の中身は%dです\n", num2[0]);
	printf("5段目の中身は%dです\n", num2[1]);
	printf("6段目の中身は%dです\n", num2[2]);

	return 0;
}
