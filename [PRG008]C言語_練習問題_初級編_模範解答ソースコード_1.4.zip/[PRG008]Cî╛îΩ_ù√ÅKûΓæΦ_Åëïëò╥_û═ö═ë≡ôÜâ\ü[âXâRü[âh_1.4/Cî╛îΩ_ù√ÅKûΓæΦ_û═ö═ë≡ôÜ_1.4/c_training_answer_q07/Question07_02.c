#include <stdio.h>
int main(void) {
	int iNumbers[] = { 10,20,30,40,50,60,70,80,90 };
	const int iLength=9; //配列サイズ

	printf("入れ替え前の状態：");
	for(int i = 0;i < iLength;i++){
		printf(" %d ",iNumbers[i]);
	}

	for(int i=0;i < iLength/2;i++){
		int temp =iNumbers[i];
		iNumbers[i]=iNumbers[iLength-(i+1)];
		iNumbers[iLength-(i+1)]=temp;
	}
	
	printf("\n入れ替え後の状態：");
	for(int i = 0;i < iLength;i++){
		printf(" %d ",iNumbers[i]);
	}

	return 0;
}