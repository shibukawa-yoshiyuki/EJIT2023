#include <stdio.h>
#include <stdbool.h>

typedef char String[1024];
//線形探査
int main(void) {
	int iNumbers[] = { 31,41,59,26,53,58,97,93,23,84 };

	String strInput="";
	int inum = 0;
	int iIndex = -1;

	printf("10～99の2桁の数値を入力してください:");
	scanf("%s",strInput);
	inum = atoi(strInput);

	for(int i = 0;i < 10;i++){
		if(iNumbers[i]==inum){
			iIndex=i;
			break;
		}
	}
	
	if(iIndex >= 0){
		printf("\n%d は、%dの位置に見つかりました",inum,iIndex);
	}else{
		printf("\n%d は、見つかりませんでした",inum);
	}
	return 0;
}
