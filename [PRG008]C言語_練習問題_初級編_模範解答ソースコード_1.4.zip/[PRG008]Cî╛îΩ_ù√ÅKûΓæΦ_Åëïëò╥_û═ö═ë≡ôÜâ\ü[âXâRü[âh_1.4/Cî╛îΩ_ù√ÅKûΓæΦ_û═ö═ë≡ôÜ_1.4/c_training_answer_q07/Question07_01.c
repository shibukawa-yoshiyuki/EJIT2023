#include <stdio.h>

int main(void) {
	int iTestScore[] = { 88, 63, 54, 76, 45 };
	int iSum = 0;
	
	for(int i = 0;i < 5;i++){
		iSum += iTestScore[i];
	}
	printf("5科目の合計点：%d\n", iSum);
	printf("5科目の平均点：%.1f\n",(double)iSum/5);

	return 0;
}
