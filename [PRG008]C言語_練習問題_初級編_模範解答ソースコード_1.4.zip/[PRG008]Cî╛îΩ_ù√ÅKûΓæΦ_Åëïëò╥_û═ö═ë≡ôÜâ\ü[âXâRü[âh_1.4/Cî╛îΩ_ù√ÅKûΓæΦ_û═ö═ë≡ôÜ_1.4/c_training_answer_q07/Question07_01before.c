#include <stdio.h>

int main(void) {

	int iEnglish = 88;
	int iMathematics = 62;
	int iHistory = 54;
	int iScience = 76;
	int iGeography = 45;

	int sum = english + mathematics + history + science + geography;

	printf("テストの合計点は%d点です", sum);

	return 0;

}
