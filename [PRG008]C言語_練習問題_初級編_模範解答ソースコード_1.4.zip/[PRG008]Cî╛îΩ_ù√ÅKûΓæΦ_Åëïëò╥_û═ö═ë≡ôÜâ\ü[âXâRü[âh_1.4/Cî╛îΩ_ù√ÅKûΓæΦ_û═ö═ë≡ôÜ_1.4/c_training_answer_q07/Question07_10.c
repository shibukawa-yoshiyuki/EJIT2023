#include <stdio.h>

int main(void) {
	int ibefore[][4] = {{0,1,2,3},{4,5,6,7},{8,9,10,11},{12,13,14,15}};
	int tate=4;
	int yoko=4;
	int iafter[4][4];

	printf("入れ替え前\n");

	for(int i = 0;i < tate; i++){
		for(int j = 0;j < yoko; j++){
			printf("  %4d",ibefore[i][j]);
		}
		printf("\n");
	}
	for(int i = 0;i < tate; i++){
		
		for(int j = 0;j < yoko; j++){
			iafter[i][j]=ibefore[j][i];
		}
	}
	printf("入れ替え後\n");
	for(int i = 0;i < tate; i++){
		for(int j = 0;j < yoko; j++){
			printf("  %4d",iafter[i][j]);
		}
		printf("\n");
	}

	
	return 0;
}