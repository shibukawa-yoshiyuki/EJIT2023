#include <stdio.h>
#include <stdbool.h>

typedef char String[1024];
const int TAXRATE_8 = 8;
const int TAXRATE_10 = 10;
typedef struct {
	int price;
	int tax8Price;
	int tax10Price;
	int priceTax8in;
	int priceTax10in;
}tagLunchBox;

void initLunchBoxData(int lunchBoxPrice,tagLunchBox *lunchbox){
	lunchbox->price = lunchBoxPrice;
	lunchbox->tax8Price = taxCalc(lunchBoxPrice,TAXRATE_8);
	lunchbox->priceTax8in =lunchbox->price+lunchbox->tax8Price;
	lunchbox->tax10Price = taxCalc(lunchBoxPrice,TAXRATE_10);
	lunchbox->priceTax10in =lunchbox->price+lunchbox->tax10Price;
}

int taxCalc(int lunchBoxPrice,const int taxRate) {
	lunchBoxPrice *= (double)(taxRate/100.0);
	return lunchBoxPrice;
}

void showPrice(tagLunchBox *lunchbox, bool bEatinFlg) {

	if(!bEatinFlg){
		//持ち帰り
		printf("持ち帰りの税率: %d%%\n", TAXRATE_8);
		printf("税込み(%d%%)価格\t: %d円\n", TAXRATE_8,lunchbox->priceTax8in);
		printf("消費税額(%d%%)\t: %d円\n", TAXRATE_8,lunchbox->tax8Price);
	}else{
		//イートイン
		printf("イートインの税率: %d%%\n", TAXRATE_10);
		printf("税込み(%d%%)価格\t: %d円\n", TAXRATE_10,lunchbox->priceTax10in);
		printf("消費税額(%d%%)\t: %d円\n", TAXRATE_10,lunchbox->tax10Price);
	}
}

int main(void) {

	String strInput="";
	printf("お弁当の本体価格を入力してください。\n");
	scanf("%s",strInput);
	int lunchBoxPrice = atoi(strInput);

	tagLunchBox lunchbox;
	// 構造体の初期化処理
	initLunchBoxData(lunchBoxPrice,&lunchbox);
	
	printf("持ち帰りの場合:0、イートインの場合:1を入力してください。\n");
	scanf("%s",strInput);
	bool bEatinFlg = atoi(strInput);

	showPrice(&lunchbox,bEatinFlg);

	return 0;
}


