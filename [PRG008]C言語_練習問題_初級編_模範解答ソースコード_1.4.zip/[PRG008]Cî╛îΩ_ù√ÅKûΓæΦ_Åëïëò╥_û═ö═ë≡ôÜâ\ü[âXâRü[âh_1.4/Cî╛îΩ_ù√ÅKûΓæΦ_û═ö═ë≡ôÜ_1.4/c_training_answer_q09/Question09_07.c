#include <stdio.h>

typedef char String[1024];
const double PI = 3.14;

//半径から円周を計算する
void calcCircleLength(double dRadius,double *circleLength) {
	*circleLength = 2.0*PI*dRadius;
	return;
}
//半径から円の面積を計算する
void calcCircleArea(double dRadius,double *circleArea) {
	*circleArea = dRadius * dRadius * PI;
	return;
}

int main(void)
{
	String strInput="";
	double circleLength=0.0;
	double circleArea=0.0;
	int inum = 0;
	
	printf("半径を1～9の数値1桁で入力してください\n");
	printf("半径：");
	scanf("%s",strInput);
	inum = atoi(strInput);

	calcCircleLength((double)inum,&circleLength);
	calcCircleArea((double)inum,&circleArea);
	printf("円周：%.2f\n", circleLength);
	printf("円の面積：%.2f\n",circleArea);
	return 0;
}