#include <stdio.h>

int main(void) {
	int iarray[][4] = {{0,1,2,3},{4,5,6,7},{8,9,10,11},{12,13,14,15}};
	int tate=4;
	int yoko=4;
	int *pArray;
	pArray =(int *)iarray;

	printf("入れ替え前\n");

	for(int i = 0;i < tate; i++){
		for(int j = 0;j < yoko; j++){
			printf("  %4d",iarray[i][j]);
		}
		printf("\n");
	}
	for(int i = 0;i < (tate*yoko)-1;i++){
		for(int j=0; j<(tate*yoko)-1-i;j++){
			if(pArray[j] < pArray[j+1]){
				int tmp=pArray[j];
				pArray[j]=pArray[j+1];
				pArray[j+1]=tmp;
			}
		}
	}
	

	printf("入れ替え後\n");
	for(int i = 0;i < tate; i++){
		for(int j = 0;j < yoko; j++){
			printf("  %4d",iarray[i][j]);
		}
		printf("\n");
	}

	
	return 0;
}