#include <stdio.h>

typedef char String[1024];
typedef struct{
	String name;
	int age;
	double height;
	double weight;
	String favoriteFood;
}tagCat;

void showProfile(tagCat* pCat){
	printf("名前は%sです\n", pCat->name);
	printf("年齢は%d歳です\n", pCat->age);
	printf("身長は%.1fcmです\n", pCat->height);
	printf("体重は%.1fkgです\n", pCat->weight);
	printf("好きな食べ物は%sです\n", pCat->favoriteFood);
	
	return;
}
int main(void) {


	tagCat cat = { "コタロウ",7,52.3,4.8,"ささみ" };

	showProfile(&cat);

	return 0;
}