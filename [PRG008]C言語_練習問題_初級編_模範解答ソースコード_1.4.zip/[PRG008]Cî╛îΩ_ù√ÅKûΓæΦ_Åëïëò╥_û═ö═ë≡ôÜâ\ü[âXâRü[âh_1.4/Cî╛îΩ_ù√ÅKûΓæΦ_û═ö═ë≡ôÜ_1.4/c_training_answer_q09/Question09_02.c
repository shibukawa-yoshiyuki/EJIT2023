#include <stdio.h>
int main()
{
	char cmoji[6] = "ABCDE";

	char *pmoji[6];

	for(int i=0;i < 5;i++){
		pmoji[i]=&cmoji[i];
	}

	for(int i=0;i < 5;i++){
	    printf("*pmoji[%d]: %c\tpmoji[%d](cmoji1[%d]のアドレス番号): %p\n",i,*pmoji[i],i,i,pmoji[i]);
	}

	return 0;
}