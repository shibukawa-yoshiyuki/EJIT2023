#include <stdio.h>

int main( void )
{
	int iNum =1;
	int *pNum;
	pNum = &iNum;
	char cMoji = 'A';
	char *pMoji;
	pMoji = &cMoji;
	
	//変数cMojiのアドレスをpMojiに代入 
	printf( "-----初期値を表示-----\n");
	printf( "*pNum : %d\tpNum : %p\n", *pNum,pNum );
	printf( "*pMoji: %c\tpMoji: %p\n", *pMoji,pMoji);
	
	++*pNum;
	++*pMoji;
	printf( "-----前置インクリメント[++*pNum,++*pMoji]の結果を表示-----\n");
	printf( "*pNum : %d\tpNum : %p\n", *pNum,pNum );
	printf( "*pMoji: %c\tpMoji: %p\n", *pMoji,pMoji);

	(*pNum)++;
	(*pMoji)++;
	printf( "-----後置インクリメント（）あり[(*pNum)++,(*pMoji)++］の結果を表示-----\n");
	printf( "*pNum : %d\tpNum : %p\n", *pNum,pNum );
	printf( "*pMoji: %c\tpMoji: %p\n", *pMoji,pMoji);

	*pNum++;
	*pMoji++;
	printf( "-----後置インクリメント（）なし[*pNum++,*pMoji++］の結果を表示-----\n");
	printf( "*pNum : %d\tpNum : %p\n", *pNum,pNum );
	printf( "*pMoji: %c\tpMoji: %p\n", *pMoji,pMoji);

	return 0;
}
