#include <stdio.h>
int main(void)
{
//    int inum1 = 1;
//    int inum2 = 2;
//    int inum3 = 3;

	int inum[] = {1,2,3};

	int *pnum1;
	int *pnum2;
	int *pnum3;

	pnum1=&inum[0];
	pnum2=&inum[1];
	pnum3=&inum[2];

    printf("*pnum1: %d\tpnum1(inum[0]のアドレス番号): %p\n",*pnum1,pnum1);
    printf("*pnum2: %d\tpnum2(inum[1]のアドレス番号): %p\n",*pnum2,pnum2);
    printf("*pnum3: %d\tpnum3(inum[2]のアドレス番号): %p\n",*pnum3,pnum3);
	
	return 0;

}
