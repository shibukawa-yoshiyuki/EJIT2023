#include <stdio.h>
typedef char String[1024];

//科目名と点数の構造体
typedef struct{
	String strKamoku;
	int iScore;
}tagKamokuScore;

//科目名と点数の構造体
typedef struct{
	char cInitmoji;
	int iKamokuCnt;
	tagKamokuScore scores[5];
	int iTotal;
	double dAvg;
}tagStudentScore;

void inputKamoku(tagStudentScore *student){
	String strInput="";
	for(int i=0; i< student->iKamokuCnt; i++){
		printf("\n%dつ目の科目名を入力してください: ",i+1);
		scanf("%s",student->scores[i].strKamoku);
	}
}

void inputScore(tagStudentScore *student){
	String strInput="";
	printf("\n\n%cさんのテスト結果を入力してください\n", student->cInitmoji);
	
	for(int i=0; i< student->iKamokuCnt; i++){
		printf("\n科目:%sの点数を入力してください : ",student->scores[i].strKamoku);
		scanf("%s",strInput);
		student->scores[i].iScore = atoi(strInput);
	}
}

void calcTotalScore(tagStudentScore *student){

	student->iTotal=0;
	for(int i=0; i< student->iKamokuCnt; i++){
		student->iTotal += student->scores[i].iScore;
	}
	student->dAvg = (double)student->iTotal/student->iKamokuCnt;
}

int main(void) {
	
	tagStudentScore student;	
	student.iKamokuCnt=5;
	
	inputKamoku(&student); //科目名の入力

	printf("\n苗字の頭文字をアルファベット1文字で入力してください : ");
	String strInput="";
	scanf("%s",strInput);
	student.cInitmoji = strInput[0];

	inputScore(&student);

	calcTotalScore(&student);
	
	printf("\n---%cさんのテスト結果---\n", student.cInitmoji);
	printf("%d科目の合計点 : %d\n", student.iKamokuCnt,student.iTotal);
	printf("%d科目の平均点 : %.1f\n", student.iKamokuCnt,student.dAvg);
	return 0;

}
