#include <stdio.h>

int main( void )
{
	char cMoji = 'A';
	char *pMoji;
	
	pMoji = &cMoji;
	printf( "%c\n", *pMoji );
	++*pMoji;
	printf( "%c\n", *pMoji );
	return 0;
}

