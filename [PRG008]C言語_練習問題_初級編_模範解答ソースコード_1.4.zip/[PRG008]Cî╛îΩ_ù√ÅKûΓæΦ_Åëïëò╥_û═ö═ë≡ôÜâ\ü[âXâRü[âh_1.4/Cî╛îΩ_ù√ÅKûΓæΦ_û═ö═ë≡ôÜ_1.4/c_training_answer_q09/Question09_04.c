#include <stdio.h>

int main( void )
{
	int const cntAlpha=26;
	char cMoji = 'A';
	char *pMoji;
	pMoji = &cMoji;
	
	int i;
	printf("---AからZを表示---\n");
	for(i=0;i<cntAlpha;i++){
		printf( " <%c>",*pMoji);
		*pMoji=*pMoji+1;
		if(i==12){
			printf( "\n");
		}
	}
	printf("\n---ZからAを表示---\n");
	for(i=cntAlpha;i>0;i--){
		*pMoji=*pMoji-1;
		printf( " >%c<",*pMoji);
		if(i==cntAlpha-12){
			printf( "\n");
		}
	}
	
	return 0;
}
