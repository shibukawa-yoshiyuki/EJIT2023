#include <stdio.h>

int main(void) {

	printf("ようこそ C へ");
	
	return 0;
}
