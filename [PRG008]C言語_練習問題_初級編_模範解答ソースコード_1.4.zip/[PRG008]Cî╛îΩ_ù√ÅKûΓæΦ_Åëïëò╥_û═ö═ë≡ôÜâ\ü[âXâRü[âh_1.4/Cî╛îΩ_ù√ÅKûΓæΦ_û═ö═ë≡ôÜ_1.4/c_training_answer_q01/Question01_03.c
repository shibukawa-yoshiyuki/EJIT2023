#include <stdio.h>

int main(void) {

	printf("出力の練習  ");
	printf("３回目\n");
	printf("出力を終了します ");

	return 0;
}
