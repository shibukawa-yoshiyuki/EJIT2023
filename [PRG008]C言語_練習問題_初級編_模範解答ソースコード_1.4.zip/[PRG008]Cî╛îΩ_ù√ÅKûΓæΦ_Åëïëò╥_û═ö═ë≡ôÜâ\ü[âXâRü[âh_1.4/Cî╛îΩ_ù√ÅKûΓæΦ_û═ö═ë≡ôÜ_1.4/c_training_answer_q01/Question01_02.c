#include <stdio.h>

int main(void) {

	printf("出力の練習  ");
	printf("２回目\n");

	return 0;
}