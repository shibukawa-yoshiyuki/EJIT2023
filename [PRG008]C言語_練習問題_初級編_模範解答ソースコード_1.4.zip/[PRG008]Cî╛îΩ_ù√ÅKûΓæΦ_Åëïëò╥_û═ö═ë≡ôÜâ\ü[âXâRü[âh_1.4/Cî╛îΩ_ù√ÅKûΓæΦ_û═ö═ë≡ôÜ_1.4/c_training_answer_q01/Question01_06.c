#include <stdio.h>

int main(void) {

	//メッセージ"表示を　"を出力
	printf("表示を　");
	//メッセージ"行います"を出力後改行 
	printf("行います\n");	
	//メッセージ"終了します"を出力後改行 
	printf("終了します\n");

	return 0;
}

