#include <stdio.h>

/*
	メッセージを表示するプログラムです。
	作成日：2020年3月4日
	作成者：システムシェアード 松本
 */
int main(void) {

	printf("メッセージを表示する　");
	printf("プログラムです\n");	
	printf("プログラムを終了します\n");

	return 0;
}
