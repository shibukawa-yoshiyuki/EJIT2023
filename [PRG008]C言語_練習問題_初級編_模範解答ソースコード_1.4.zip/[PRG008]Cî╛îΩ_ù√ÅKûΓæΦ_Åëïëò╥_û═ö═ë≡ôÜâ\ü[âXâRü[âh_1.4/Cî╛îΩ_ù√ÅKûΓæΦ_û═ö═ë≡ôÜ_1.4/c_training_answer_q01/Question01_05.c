#include <stdio.h>

int main(void) {
	printf("赤パジャマ\n");
	printf("青パジャマ\n"); 
	printf("黄パジャマ\n");
	return 0;
}
