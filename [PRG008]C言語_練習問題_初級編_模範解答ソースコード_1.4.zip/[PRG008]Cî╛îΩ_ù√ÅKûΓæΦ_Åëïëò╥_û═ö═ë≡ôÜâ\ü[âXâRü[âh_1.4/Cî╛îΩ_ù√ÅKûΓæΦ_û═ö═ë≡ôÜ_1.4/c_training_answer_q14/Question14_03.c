#include <stdio.h>
#include <stdint.h>

//2進数表示用処理
void printbi(uint8_t n) {
    int i;
    for (i = 8 - 1; i >= 0; i--) {
        printf("%d", (n >> i) & 1);
    }
}

int main(void) {
	uint8_t a =197; // 1100 0101
	
    printf("---右へ1ビットシフト a>>1 の結果---\n");
	printf(" 計算前:\t");
	printf("10進数:%4d",a);
	printf("  2進数:");
	printbi(a);
	printf("\n");
	printf(" 計算後:\t");
	printf("10進数:%4d",a>>1);
	printf("  2進数:");
	printbi( a>>1);
	printf("\n\n");

    printf("---右へ2ビットシフト a>>2 の結果---\n");
	printf(" 計算前:\t");
	printf("10進数:%4d",a);
	printf("  2進数:");
	printbi(a);
	printf("\n");
	printf(" 計算後:\t");
	printf("10進数:%4d",a>>2);
	printf("  2進数:");
	printbi( a>>2);
	printf("\n\n");

    printf("---右へ3ビットシフト a>>3 の結果---\n");
	printf(" 計算前:\t");
	printf("10進数:%4d",a);
	printf("  2進数:");
	printbi(a);
	printf("\n");
	printf(" 計算後:\t");
	printf("10進数:%4d",a>>3);
	printf("  2進数:");
	printbi( a>>3);
	printf("\n\n");
	return 0;
}

