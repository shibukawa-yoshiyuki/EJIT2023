#include <stdio.h>
#include <stdint.h>

//2進数表示用処理
void printbi(uint8_t n) {
    int i;
    for (i = 8 - 1; i >= 0; i--) {
        printf("%d", (n >> i) & 1);
    }
}

int main(void) {
	uint8_t a =255; // 1111 1111
	uint8_t b =197; // 1100 0101
	uint8_t c =5;   // 0000 0101
	
	
	//論理積
	printf("---論理積 a & bの結果---\n");
	printf(" 計算前a:\t");
	printbi(a);
	printf("\n");
	printf(" 計算前b:\t");
	printbi(b);
	printf("\n");
	printf(" 計算後:\t");
	printbi(a & b);
	printf("\n\n");

		//論理積
	printf("---論理積 b & cの結果---\n");
	printf(" 計算前b:\t");
	printbi(b);
	printf("\n");
	printf(" 計算前c:\t");
	printbi(c);
	printf("\n");
	printf(" 計算後:\t");
	printbi(b & c);
	printf("\n\n");

	
	//論理和
	printf("---論理和 a | bの結果---\n");
	printf(" 計算前a:\t");
	printbi(a);
	printf("\n");
	printf(" 計算前b:\t");
	printbi(b);
	printf("\n");
	printf(" 計算後:\t");
	printbi( a | b);
	printf("\n\n");
	
	//論理和
	printf("---論理和 b | cの結果---\n");
	printf(" 計算前b:\t");
	printbi(b);
	printf("\n");
	printf(" 計算前c:\t");
	printbi(c);
	printf("\n");
	printf(" 計算後:\t");
	printbi( b | c);
	printf("\n\n");

	//排他的論理和
	printf("---排他的論理和 a ^ bの結果---\n");
	printf(" 計算前a:\t");
	printbi(a);
	printf("\n");
	printf(" 計算前b:\t");
	printbi(b);
	printf("\n");
	printf(" 計算後:\t");
	printbi( a ^ b);
	printf("\n\n");

	printf("---排他的論理和 b ^ cの結果---\n");
	printf(" 計算前b:\t");
	printbi(b);
	printf("\n");
	printf(" 計算前c:\t");
	printbi(c);
	printf("\n");
	printf(" 計算後:\t");
	printbi( b ^ c);
	printf("\n\n");

	//否定演算
	printf("---否定 ~aの結果---\n");
	printf(" 計算前a:\t");
	printbi(a);
	printf("\n");
	printf(" 計算後:\t");
	printbi( ~a);
	printf("\n\n");

	printf("---否定 ~bの結果---\n");
	printf(" 計算前b:\t");
	printbi(b);
	printf("\n");
	printf(" 計算後:\t");
	printbi( ~b);
	printf("\n\n");

	printf("---否定 ~cの結果---\n");
	printf(" 計算前c:\t");
	printbi(c);
	printf("\n");
	printf(" 計算後:\t");
	printbi( ~c);
	printf("\n\n");

	return 0;
}

