#include <stdio.h>
#include <stdint.h>

void printbi(uint8_t n) {
    int i;
    for (i = 8 - 1; i >= 0; i--) {
        printf("%d", (n >> i) & 1);
    }
}

int main(void)
{
	uint8_t a =255; // 1111 1111
	uint8_t b =197; // 1100 0101
	uint8_t c =5;   // 0000 0101

	printf("16進数、10進数、2進数表記で表示します\n");
	printf("---aの値---\n");
	printf("16進数:%02x\n",a);
	printf("10進数:%d\n",a);
	printf("2進数:");
	printbi(a);
	printf("\n");

	printf("\n---bの値---\n");
	printf("16進数:%02x\n",b);
	printf("10進数:%d\n",b);
	printf("2進数:");
	printbi(b);
	printf("\n");

	printf("\n---cの値---\n");
	printf("16進数:0x%02x\n",c);
	printf("10進数:%d\n",c);
	printf("2進数:");
	printbi(c);

	
	return 0;
}