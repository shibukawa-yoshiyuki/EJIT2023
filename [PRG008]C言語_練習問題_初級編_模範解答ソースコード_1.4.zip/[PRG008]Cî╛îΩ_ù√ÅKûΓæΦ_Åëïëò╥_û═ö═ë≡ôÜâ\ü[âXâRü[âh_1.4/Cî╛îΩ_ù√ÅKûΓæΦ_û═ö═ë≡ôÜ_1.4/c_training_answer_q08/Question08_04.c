#include <stdio.h>

typedef char String[1024];

//三角形の面積を算出
double triangleCalcArea(int iBottom, int iHeight) {
	return (double)(iBottom * iHeight) / 2;
}

int main(void) {
	typedef struct {
		int iBottom;
		int iHeight;
		double dArea;
	} tagTriangle;

	tagTriangle triangle = {0,0,0.0};

	String strInput="";
	
	printf("三角形の底辺の長さを1～9の1桁の数値で入力してください\n");
	printf("底辺：");
	scanf("%s",strInput);
	triangle.iBottom = atoi(strInput);

	printf("三角形の高さを1～9の1桁の数値で入力してください\n");
	printf("高さ：");
	scanf("%s",strInput);
	triangle.iHeight = atoi(strInput);

	triangle.dArea = triangleCalcArea(triangle.iBottom,triangle.iHeight);
	printf("三角形の面積は%.2fです", triangle.dArea);

	return 0;
}