#include <stdio.h>

typedef char String[1024];
const double PI = 3.14;

//半径から円周を計算する
double calcCircleLength(double dRadius) {
	return 2.0*PI*dRadius;
}
//半径から円の面積を計算する
double calcCircleArea(double dRadius) {
	return dRadius * dRadius * PI;
}

int main(void)
{
	String strInput="";
	int inum = 0;
	
	printf("半径を1～9の数値1桁で入力してください\n");
	printf("半径：");
	scanf("%s",strInput);
	inum = atoi(strInput);

	printf("円周：%.2f\n", calcCircleLength((double)inum));
	printf("円の面積：%.2f\n", calcCircleArea((double)inum));
	return 0;
}