#include <stdio.h>

typedef char String[1024];
const int TAXRATE_8 = 8;
const int TAXRATE_10 = 10;

int tax8Calc(int lunchBoxPrice) {

	lunchBoxPrice *= (double)(TAXRATE_8/100.0);

	return lunchBoxPrice;
}
int tax10Calc(int lunchBoxPrice) {

	lunchBoxPrice *= (double)(TAXRATE_10/100.0);

	return lunchBoxPrice;
}

int main(void) {

	String strInput="";
	printf("お弁当の本体価格を入力してください。\n");
	scanf("%s",strInput);
	int lunchBoxPrice = atoi(strInput);

	int lunchBoxTax8Price = tax8Calc(lunchBoxPrice);
	int lunchBoxTax10Price = tax10Calc(lunchBoxPrice);

	printf("税込み(%d%%)価格\t: %d円\n", TAXRATE_8,lunchBoxPrice+lunchBoxTax8Price);
	printf("消費税額(%d%%)\t: %d円\n", TAXRATE_8,lunchBoxTax8Price);
	printf("税込み(%d%%)価格\t: %d円\n", TAXRATE_10,lunchBoxPrice+lunchBoxTax10Price);
	printf("消費税額(%d%%)\t: %d円\n", TAXRATE_10,lunchBoxTax10Price);

	return 0;
}


