#include <stdio.h>
#include <stdbool.h>

typedef char String[1024];
const int TAXRATE_8 = 8;
const int TAXRATE_10 = 10;

int taxCalc(int lunchBoxPrice,const int taxRate) {

	lunchBoxPrice *= (double)(taxRate/100.0);

	return lunchBoxPrice;
}

void showPrice(int lunchBoxPrice, bool bEatinFlg) {

	int lunchBoxTaxPrice=0;
	int taxRate=0;
	if(!bEatinFlg){
		//持ち帰り
		taxRate=TAXRATE_8;
		printf("持ち帰り");
	}else{
		//イートイン
		taxRate=TAXRATE_10;
		printf("イートイン");
	}
	lunchBoxTaxPrice= taxCalc(lunchBoxPrice,taxRate);
	printf("の税率: %d%%\n", taxRate);
	printf("税込み(%d%%)価格\t: %d円\n", taxRate,lunchBoxPrice+lunchBoxTaxPrice);
	printf("消費税額(%d%%)\t: %d円\n", taxRate,lunchBoxTaxPrice);
}

int main(void) {

	String strInput="";
	printf("お弁当の本体価格を入力してください。\n");
	scanf("%s",strInput);
	int lunchBoxPrice = atoi(strInput);

	printf("持ち帰りの場合:0、イートインの場合:1を入力してください。\n");
	scanf("%s",strInput);
	bool bEatinFlg = atoi(strInput);

	showPrice(lunchBoxPrice,bEatinFlg);

	return 0;
}


