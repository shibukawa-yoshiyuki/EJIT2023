#include <stdio.h>

typedef char String[1024];
const int TAXRATE_8 = 8;
const int TAXRATE_10 = 10;

int taxCalc(int lunchBoxPrice,const int taxRate) {

	lunchBoxPrice *= (double)(taxRate/100.0);

	return lunchBoxPrice;
}


int main(void) {

	String strInput="";
	printf("お弁当の本体価格を入力してください。\n");
	scanf("%s",strInput);
	int lunchBoxPrice = atoi(strInput);

	int lunchBoxTax8Price = taxCalc(lunchBoxPrice,TAXRATE_8);
	int lunchBoxTax10Price = taxCalc(lunchBoxPrice,TAXRATE_10);

	printf("税込み(%d%%)価格\t: %d円\n", TAXRATE_8,lunchBoxPrice+lunchBoxTax8Price);
	printf("消費税額(%d%%)\t: %d円\n", TAXRATE_8,lunchBoxTax8Price);
	printf("税込み(%d%%)価格\t: %d円\n", TAXRATE_10,lunchBoxPrice+lunchBoxTax10Price);
	printf("消費税額(%d%%)\t: %d円\n", TAXRATE_10,lunchBoxTax10Price);

	return 0;
}


