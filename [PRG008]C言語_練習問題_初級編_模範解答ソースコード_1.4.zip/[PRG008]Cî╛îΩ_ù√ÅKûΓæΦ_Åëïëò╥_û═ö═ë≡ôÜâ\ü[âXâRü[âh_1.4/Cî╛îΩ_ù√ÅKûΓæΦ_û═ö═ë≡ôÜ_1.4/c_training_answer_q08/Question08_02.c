#include <stdio.h>

typedef char String[1024];

int mathMaxCheck(int inum1, int inum2) {

	int iresult = 0;
	if (inum1 > inum2) {
		iresult = 1;
	}else if(inum1 == inum2) {
		iresult = 2;
	}else {
		iresult = 3;
	}
	return iresult;
}


int main(void) {
	String strInput="";
	int inum1 = 0;
	int inum2 = 0;
	
	printf("2桁の数値を2回入力してください\n");
	printf("1回目：");
	scanf("%s",strInput);
	inum1 = atoi(strInput);

	printf("\n2回目：");
	scanf("%s",strInput);
	inum2 = atoi(strInput);

	printf("数値の比較をします\n");
	
	switch(mathMaxCheck(inum1 , inum2)){
		case 1:
			printf("1回目と2回目で大きい値は%dです", inum1);
			break;
		case 2:
			printf("1回目と2回目の値は、%dで同じ値です", inum1);
			break;
		case 3:
			printf("1回目と2回目で大きい値は%dです", inum2);
			break;
		default:
			printf("判断できませんでした");
			break;
	}

	return 0;
}