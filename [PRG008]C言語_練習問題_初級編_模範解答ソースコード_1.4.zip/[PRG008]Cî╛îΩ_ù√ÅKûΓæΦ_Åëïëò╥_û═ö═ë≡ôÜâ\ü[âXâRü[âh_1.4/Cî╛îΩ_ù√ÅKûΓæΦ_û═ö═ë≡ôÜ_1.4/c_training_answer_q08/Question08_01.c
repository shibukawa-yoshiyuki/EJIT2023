#include <stdio.h>

typedef char String[1024];

int mathMax(int inum1, int inum2) {

	if (inum1 < inum2) {
		return inum2;
	}else {
		return inum1;
	}

}


int main(void) {
	String strInput="";
	int inum1 = 0;
	int inum2 = 0;
	
	printf("2桁の数値を2回入力してください\n");
	printf("1回目：");
	scanf("%s",strInput);
	inum1 = atoi(strInput);

	printf("\n2回目：");
	scanf("%s",strInput);
	inum2 = atoi(strInput);

	printf("数値の比較をします\n");
	printf("1回目と2回目で大きい値は%dです", mathMax(inum1 , inum2));

	return 0;
}