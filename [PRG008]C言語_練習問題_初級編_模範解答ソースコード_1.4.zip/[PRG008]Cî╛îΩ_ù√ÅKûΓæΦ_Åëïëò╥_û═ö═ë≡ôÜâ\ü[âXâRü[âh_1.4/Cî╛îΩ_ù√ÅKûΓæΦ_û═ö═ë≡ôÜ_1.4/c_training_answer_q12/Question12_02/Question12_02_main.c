#include <stdio.h>
#include "sub.h"

int main(void) {
	int inum = 10;

	printf("main: sub関数呼び出し前 : %d\n", inum);
	sub(&inum);
	printf("main: sub関数呼び出し後 : %d\n", inum);

	return 0;

}
