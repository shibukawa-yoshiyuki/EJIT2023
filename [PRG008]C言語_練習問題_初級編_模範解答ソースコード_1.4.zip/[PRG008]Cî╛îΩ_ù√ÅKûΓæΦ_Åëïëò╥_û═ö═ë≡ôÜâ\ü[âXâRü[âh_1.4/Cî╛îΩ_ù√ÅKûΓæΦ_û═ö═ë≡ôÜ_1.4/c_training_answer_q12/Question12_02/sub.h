#ifndef __SUB_H__
#define __SUB_H__

void sub(int *inum);

#endif