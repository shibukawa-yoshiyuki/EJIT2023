#include <stdio.h>
#include "sub.h"

void sub(int *inum) {
	printf("sub: sub関数処理前 : %d\n", *inum);
	*inum += 5;
	printf("sub: sub関数処理後 : %d\n", *inum);
}