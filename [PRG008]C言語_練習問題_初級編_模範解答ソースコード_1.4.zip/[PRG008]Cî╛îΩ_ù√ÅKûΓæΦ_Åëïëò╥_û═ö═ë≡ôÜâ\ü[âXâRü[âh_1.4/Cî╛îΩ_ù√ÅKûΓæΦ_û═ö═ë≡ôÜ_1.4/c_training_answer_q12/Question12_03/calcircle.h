#ifndef __CALCIRCLE_H__
#define __CALCIRCLE_H__


void calcCircleLength(double dRadius,double *circleLength);
void calcCircleArea(double dRadius,double *circleArea);
void makeStringLength(char str[256],double *circleLength);
void makeStringArea(char str[256],double *circleArea);
void makeStringLengthArea(char str[256],double *circleLength,double *circleArea);

#endif