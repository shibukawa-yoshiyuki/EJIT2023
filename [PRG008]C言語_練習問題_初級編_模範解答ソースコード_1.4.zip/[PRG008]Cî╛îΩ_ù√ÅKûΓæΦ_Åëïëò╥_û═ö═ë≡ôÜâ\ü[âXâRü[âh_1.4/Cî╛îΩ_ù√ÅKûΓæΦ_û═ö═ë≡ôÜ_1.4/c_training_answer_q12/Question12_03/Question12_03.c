#include <stdio.h>
#include <stdbool.h>
#include "changechar.h"
#include "calcircle.h"

int main(void)
{
	double circleLength=0.0;
	double circleArea=0.0;
	double dnum = 0;
	char menu = '0';
	bool outputflg = 0;
	char outputStr[256];
	
	printf("---円周率、円の面積を計算するプログラム---\n");

	printf("半径を小数点第1位までの数値で入力してください\n");
	printf("半径: ");
	scanf("%lf",&dnum);
	
	//代入抑止
	// 連続してscanfを行う場合の回避方法
	//https://ja.wikipedia.org/wiki/Scanf
	scanf("%*c"); 

	while(!outputflg){
		printf("\nメニューの文字を入力してください\n");
		printf("A or a: 円周と円の面積を表示\n");
		printf("B or b: 円周を表示\n");
		printf("C or c: 円の面積を表示\n");
		printf("メニューの文字: \n");
		scanf("%c",&menu);
		changeLowertoUpper(&menu);

		if(menu=='A'){
			calcCircleLength(dnum,&circleLength);
			calcCircleArea(dnum,&circleArea);
			makeStringLengthArea(outputStr,&circleLength,&circleArea);
			outputflg=true;
		}else if(menu=='B'){
			calcCircleLength(dnum,&circleLength);
			makeStringLength(outputStr,&circleLength);
			outputflg=true;
		}else if(menu=='C'){
			calcCircleArea(dnum,&circleArea);
			makeStringArea(outputStr,&circleArea);
			outputflg=true;
		}else{
			printf("\nもう一度入力してください\n");
			scanf("%*c"); //代入抑止
		}
	}
	printf("%s",outputStr);
	return 0;
}