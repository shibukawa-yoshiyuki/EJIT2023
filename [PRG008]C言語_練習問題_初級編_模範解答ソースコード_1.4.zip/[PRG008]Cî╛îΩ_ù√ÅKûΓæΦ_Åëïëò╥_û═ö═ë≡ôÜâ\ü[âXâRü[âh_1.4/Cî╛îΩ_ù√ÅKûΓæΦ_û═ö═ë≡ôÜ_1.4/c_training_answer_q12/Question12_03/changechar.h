#ifndef __CHANGECHAR_H__
#define __CHANGECHAR_H__

void changeLowertoUpper(char *cmoji);

#endif