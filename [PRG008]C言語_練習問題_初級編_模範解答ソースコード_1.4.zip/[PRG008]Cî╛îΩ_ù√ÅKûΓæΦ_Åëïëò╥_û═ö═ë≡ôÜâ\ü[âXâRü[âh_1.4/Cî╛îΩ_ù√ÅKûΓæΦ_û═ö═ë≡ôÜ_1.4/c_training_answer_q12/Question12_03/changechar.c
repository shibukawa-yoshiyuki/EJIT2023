#include "changechar.h"

//英小文字→英大文字に変換
void changeLowertoUpper(char *cmoji){
	if('a'<= *cmoji && *cmoji<= 'z'){
		*cmoji=*cmoji-('a'-'A');
	}
}
