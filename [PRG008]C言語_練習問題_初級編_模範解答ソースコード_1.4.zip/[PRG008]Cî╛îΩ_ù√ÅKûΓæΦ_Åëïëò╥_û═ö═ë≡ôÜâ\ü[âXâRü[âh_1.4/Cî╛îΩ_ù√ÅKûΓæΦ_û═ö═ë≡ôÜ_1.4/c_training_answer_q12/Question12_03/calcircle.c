#include <stdio.h>
#include <stdbool.h>
#include "calcircle.h"

const double PI = 3.14;


//半径から円周を計算する
void calcCircleLength(double dRadius,double *circleLength) {
	*circleLength = 2.0*PI*dRadius;
	return;
}
//半径から円の面積を計算する
void calcCircleArea(double dRadius,double *circleArea) {
	*circleArea = dRadius * dRadius * PI;
	return;
}
//円周表示の文字列を作る
void makeStringLength(char str[256],double *circleLength){
	sprintf(str,"\n---円周を表示します---\n円周 : %.2f\n", *circleLength);
}
//円の面積表示の文字列を作る
void makeStringArea(char str[256],double *circleArea){
	sprintf(str,"\n---円の面積を表示します---\n円の面積：%.2f\n",*circleArea);
}
//円周、円の面積表示の文字列を作る
void makeStringLengthArea(char str[256],double *circleLength,double *circleArea){
	char strLength[256];
	char strArea[256];
	makeStringLength(strLength,circleLength);
	makeStringArea(strArea,circleArea);
	sprintf(str,"%s%s",strLength,strArea);
}