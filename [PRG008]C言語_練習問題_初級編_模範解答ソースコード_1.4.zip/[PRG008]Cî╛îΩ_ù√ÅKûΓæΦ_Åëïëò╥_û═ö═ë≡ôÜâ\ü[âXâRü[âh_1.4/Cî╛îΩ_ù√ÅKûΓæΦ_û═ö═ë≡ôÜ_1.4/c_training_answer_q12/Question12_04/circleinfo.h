#ifndef __CIRCLEINFO_H__
#define __CIRCLEINFO_H__

typedef struct {
	char lengthTitle[256];
	char areaTitle[256];
	double radius;
	double length;
	double area;
}tagCircleInfo;

void initCircleInfo(tagCircleInfo *circleInfo);
void inputCircleRadius(tagCircleInfo *circleInfo);
void calcCircle(tagCircleInfo *circleInfo);
void printLength(tagCircleInfo *circleInfo);
void printArea(tagCircleInfo *circleInfo);
void printLengthArea(tagCircleInfo *circleInfo);

#endif