#include <stdio.h>
#include <stdbool.h>
#include "circleinfo.h"

const double PI = 3.14;

//情報の初期化を行う
void initCircleInfo(tagCircleInfo *circleInfo){
	strcpy(circleInfo->lengthTitle,"\n---円周を表示します---\n円周 :");
	strcpy(circleInfo->areaTitle,"\n---円の面積を表示します---\n円の面積 :");
	circleInfo->radius = 0.0;
	circleInfo->length = 0.0;
	circleInfo->area = 0.0;
	return;
}

//半径の入力を受け付ける
void inputCircleRadius(tagCircleInfo *circleInfo){
	printf("半径を小数点第1位までの数値で入力してください\n");
	printf("半径: ");
	scanf("%lf",&(circleInfo->radius));
	calcCircle(circleInfo);
	return;
}

//半径から円周、円の面積を計算する
void calcCircle(tagCircleInfo *circleInfo){
	circleInfo->length = 2.0*PI*circleInfo->radius;
	circleInfo->area = circleInfo->radius * circleInfo->radius * PI;
	return;
}
//円周を表示する
void printLength(tagCircleInfo *circleInfo){
	printf("%s%.2f\n",circleInfo->lengthTitle, circleInfo->length);
	return;
}
//円の面積を表示する
void printArea(tagCircleInfo *circleInfo){
	printf("%s%.2f\n",circleInfo->areaTitle,circleInfo->area);
	return;
}
//円周、円の面積を表示する
void printLengthArea(tagCircleInfo *circleInfo){
	printLength(circleInfo);
	printArea(circleInfo);
	return;
}