#include <stdio.h>
#include <stdlib.h>
#include "changechar.h"
#include "circleinfo.h"


int main(int argc, const char **argv) {

	char menu = '0';
	tagCircleInfo circleInfo;
	initCircleInfo(&circleInfo);
	
	printf("---円周率、円の面積を計算するプログラム---\n");

	if(argc>=2){
		circleInfo.radius = atof(argv[1]);
		calcCircle(&circleInfo);
	}else{
		inputCircleRadius(&circleInfo);
		//代入抑止
		scanf("%*c"); 
	}

	while(1){
		printf("\n---設定されている半径:%.1f---\n",circleInfo.radius);
		printf("\nメニューの文字を英字で入力してください(大文字小文字区別なし)\n");
		printf("A: 円周と円の面積を表示\n");
		printf("B: 円周を表示\n");
		printf("C: 円の面積を表示\n");
		printf("D: 半径の再設定\n");
		printf("Q: 終了\n");
		printf("メニューの文字: \n");
		scanf("%c",&menu);
		changeLowertoUpper(&menu);

		if(menu=='A'){
			printLengthArea(&circleInfo);
		}else if(menu=='B'){
			printLength(&circleInfo);
		}else if(menu=='C'){
			printArea(&circleInfo);
		}else if(menu=='D'){
			inputCircleRadius(&circleInfo);
		}else if(menu=='Q'){
			break;
		}else{
			printf("\n文字が違います。もう一度入力してください\n");
		}
		scanf("%*c"); //代入抑止
	}
	printf("\n終了します\n");
	return 0;
}