#include <stdio.h>
#include "Question12_01_sub.c"

int main(void) {
	int inum = 10;

	printf("main: sub関数呼び出し前 : %d\n", inum);
	sub(&inum);
	printf("main: sub関数呼び出し後 : %d\n", inum);

	return 0;

}
