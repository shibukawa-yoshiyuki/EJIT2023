#include <stdio.h>

int main(void) {

	printf("こんにちは\n");
	
	return 0;
}