#include <stdio.h>

int main(void) {

	printf("こんばんは。\n");
	
	return 0;
}